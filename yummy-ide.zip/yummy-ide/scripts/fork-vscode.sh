#!/usr/bin/env bash
# fork-vscode.sh — clone microsoft/vscode and reskin it as Yummy IDE.
#
# Idempotent: re-running uses the existing clone.
# Read docs/04-fork-vscode.md before running this for production use.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FORK_DIR="$ROOT/yummy-ide-fork"
EXT_DIR="$ROOT/packages/extension"

echo "▸ forking VS Code into $FORK_DIR"

if [ ! -d "$FORK_DIR" ]; then
  echo "  cloning microsoft/vscode (depth 1, ~150MB)…"
  git clone --depth 1 https://github.com/microsoft/vscode "$FORK_DIR"
else
  echo "  ✓ existing clone found, skipping"
fi

cd "$FORK_DIR"

# ── 1. Brand rewrite of product.json ─────────────────────────────
echo
echo "▸ rewriting product.json"

# Use Node for safe JSON editing — sed on JSON is asking for trouble.
node <<'NODE'
const fs = require('node:fs');
const path = 'product.json';
const p = JSON.parse(fs.readFileSync(path, 'utf8'));
Object.assign(p, {
  nameShort: 'Yummy',
  nameLong: 'Yummy IDE',
  applicationName: 'yummy',
  dataFolderName: '.yummy',
  win32MutexName: 'yummy',
  licenseName: 'MIT',
  licenseUrl: 'https://github.com/yummy/yummy-ide/blob/main/LICENSE',
  serverApplicationName: 'yummy-server',
  serverDataFolderName: '.yummy-server',
  reportIssueUrl: 'https://github.com/yummy/yummy-ide/issues/new',
  urlProtocol: 'yummy',
  // Disable Microsoft telemetry endpoints (replace with your own if you have one).
  aiConfig: undefined,
  enableTelemetry: false,
  // Repoint the marketplace to OpenVSX (the open-source extension registry).
  extensionsGallery: {
    serviceUrl:    'https://open-vsx.org/vscode/gallery',
    itemUrl:       'https://open-vsx.org/vscode/item',
    resourceUrlTemplate: 'https://open-vsx.org/vscode/asset/{publisher}/{name}/{version}/Microsoft.VisualStudio.Code.WebResources/{path}',
    controlUrl: '',
    recommendationsUrl: '',
  },
  // Turn off the auto-updater until you publish your own update channel.
  updateUrl: undefined,
  quality: 'stable',
});
fs.writeFileSync(path, JSON.stringify(p, null, 2) + '\n');
console.log('  ✓ product.json updated');
NODE

# ── 2. Bundle Yummy extension as built-in ────────────────────────
echo
echo "▸ bundling Yummy extension as built-in"

# Extension must be built first.
if [ ! -d "$EXT_DIR/dist" ]; then
  echo "  building extension…"
  (cd "$EXT_DIR" && npx tsc -p tsconfig.json)
fi

DEST="$FORK_DIR/extensions/yummy"
mkdir -p "$DEST"
cp -R "$EXT_DIR/package.json" "$DEST/"
cp -R "$EXT_DIR/dist"         "$DEST/"
[ -d "$EXT_DIR/webview" ] && cp -R "$EXT_DIR/webview" "$DEST/"
# Copy bundled skills so they're available out of the box.
cp -R "$ROOT/skills"          "$DEST/skills"
echo "  ✓ extension copied to extensions/yummy"

# ── 3. Print next steps ──────────────────────────────────────────
cat <<EOF

✓ fork prepared.

Next steps (manual — these take time and a lot of disk):

  cd $FORK_DIR
  yarn          # ~10 minutes, ~2GB of node_modules
  yarn watch    # leave running in one terminal
  yarn run code # launches the dev build

For platform installers (macOS/Linux/Windows):

  yarn gulp vscode-darwin-x64
  yarn gulp vscode-linux-x64-build-deb
  yarn gulp vscode-win32-x64

See docs/04-fork-vscode.md for branding/legal/icons checklist.
EOF
