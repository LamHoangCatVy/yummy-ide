#!/usr/bin/env bash
# bootstrap.sh — one-command install for the Yummy monorepo.
#
#   bash scripts/bootstrap.sh
#
# Installs all workspace deps, builds @yummy/core, and points you at the POCs.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "▸ Yummy/IDE bootstrap"
echo "  root: $ROOT"
echo

# ── 1. Tool checks ──────────────────────────────────────────────
need() { command -v "$1" >/dev/null 2>&1 || { echo "✗ missing: $1"; exit 1; }; }
need node

NODE_MAJOR="$(node -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "✗ Node ≥ 20 required (found $(node -v))"; exit 1
fi

# Prefer pnpm, fall back to npm.
PM=""
if command -v pnpm >/dev/null 2>&1; then
  PM="pnpm"
elif command -v npm >/dev/null 2>&1; then
  PM="npm"
  echo "ℹ pnpm not found, falling back to npm (slower; install pnpm for best results)"
else
  echo "✗ need pnpm or npm"; exit 1
fi
echo "✓ using package manager: $PM"

# ── 2. Install ──────────────────────────────────────────────────
echo
echo "▸ installing dependencies (this may take a minute)…"
if [ "$PM" = "pnpm" ]; then
  pnpm install
else
  # npm workspaces equivalent
  npm install --workspaces --include-workspace-root
fi
echo "✓ installed"

# ── 3. Build core ───────────────────────────────────────────────
echo
echo "▸ building @yummy/core…"
$PM --filter @yummy/core run build || $PM -w @yummy/core run build || (cd packages/core && npx tsc -p tsconfig.json)
echo "✓ built"

# ── 4. Hint next steps ──────────────────────────────────────────
cat <<EOF

✓ ready.

Next:
  # POC 0 → 1 (offline canned responses):
  $PM --filter @yummy/poc-0-to-1 run start -- "build magic-link login" --dry-run

  # POC 1 → N (multi-repo refactor):
  $PM --filter @yummy/poc-1-to-n run start -- \\
    --workspace ./packages/poc-1-to-n/workspace.yummy.yml \\
    --task "rename field user_id → userId across all consumers" \\
    --anchors user_id,Principal --dry-run

  # VS Code extension:
  $PM --filter @yummy/extension run dev
  # then F5 in VS Code to launch the Extension Development Host

  # CLI:
  $PM --filter @yummy/cli run start

Set ANTHROPIC_API_KEY to run live instead of dry-run.
EOF
