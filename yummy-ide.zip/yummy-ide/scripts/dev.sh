#!/usr/bin/env bash
# dev.sh — convenience runner.
#
#   bash scripts/dev.sh poc-0-1     # run greenfield POC (dry-run)
#   bash scripts/dev.sh poc-1-n     # run brownfield POC (dry-run)
#   bash scripts/dev.sh ext         # watch+build the VS Code extension
#   bash scripts/dev.sh cli         # interactive CLI REPL
#   bash scripts/dev.sh build       # build all packages

set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

PM="pnpm"
command -v pnpm >/dev/null 2>&1 || PM="npm"

CMD="${1:-help}"; shift || true

case "$CMD" in
  poc-0-1)
    $PM --filter @yummy/poc-0-to-1 run start -- \
      "build magic-link login with 15-min TTL and rate limiting" \
      --dry-run --out ./out/magic-link
    ;;
  poc-1-n)
    $PM --filter @yummy/poc-1-to-n run start -- \
      --workspace ./packages/poc-1-to-n/workspace.yummy.yml \
      --task "rename field user_id → userId across all consumers" \
      --anchors user_id,Principal --dry-run \
      --out ./out/refactor
    ;;
  ext)
    $PM --filter @yummy/extension run dev
    ;;
  cli)
    $PM --filter @yummy/cli run start
    ;;
  build)
    $PM -r --parallel run build
    ;;
  *)
    cat <<EOF
usage: bash scripts/dev.sh <task>
  poc-0-1    run greenfield POC (offline)
  poc-1-n    run brownfield POC (offline)
  ext        watch+build the extension
  cli        interactive REPL
  build      build everything
EOF
    ;;
esac
