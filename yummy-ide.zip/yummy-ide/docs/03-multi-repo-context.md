# 03 — Multi-repo context system

> *How to give an LLM a shared brain across 20 codebases without exploding
> the context window or burning a fortune in embeddings.*

## The problem

Single-repo IDE assistants work because the repo *is* the context — even a
million-token model can keep the whole thing in mind. As soon as you have 5+
repos that share contracts, three failure modes appear:

1. **Ignorance** — agent edits the producer, forgets the consumers exist.
2. **Stuffing** — agent dumps every file into context, blows past the limit.
3. **Hallucination** — agent guesses what consumers look like instead of
   reading them.

Cursor, Copilot, and Claude Code all suffer from this when projects span
multiple repos. The fix isn't a bigger context window — it's a smarter
retrieval pipeline.

## The four-layer stack

```
┌─────────────────────────────────────────────────────────┐
│ Layer 4 · Embeddings (optional, semantic)               │ ← slow, fuzzy
├─────────────────────────────────────────────────────────┤
│ Layer 3 · Relation graph (consumes/publishes)           │
├─────────────────────────────────────────────────────────┤
│ Layer 2 · BM25 / FTS5 keyword search                    │
├─────────────────────────────────────────────────────────┤
│ Layer 1 · Symbol map (exact name → file:line)           │ ← fast, exact
└─────────────────────────────────────────────────────────┘
```

We always run from the bottom up and stop when we have enough. Most queries
finish at layer 1 or 2.

### Layer 1 — Symbol map (exact)

For every file in every repo, we extract:
- function / class / interface / type / const declarations (top-level only)
- import specifiers (the right-hand side of `from '…'`)

Stored in a SQLite database (`.yummy.db`):

```sql
CREATE TABLE symbols   (id, name, kind, file, line, signature, repo);
CREATE INDEX           idx_symbols_name ON symbols(name);
CREATE TABLE imports   (repo, from_file, spec);
```

Why SQLite:
- **Zero config** — single file, opens instantly
- **Fast** — sub-millisecond exact lookups even at 100k symbols
- **Persistent** — survive across runs, only re-index changed files
- **Embeddable** — works in the VS Code extension host with no server

Why not LSP: keeping 20 LSPs alive is a memory and battery disaster. LSP is
right for one repo with deep semantic queries; symbol map is right for 20
repos with shallow lookups.

Why regex extraction over tree-sitter: pragmatic 80/20. A 100-line regex
extractor handles TypeScript, JavaScript, Python, and Go well enough for
"find me the `sendMagicLink` function". Swap in tree-sitter when you need
nested-class symbols or AST-level rewrites.

### Layer 2 — BM25 / FTS5 (fuzzy keyword)

The same SQLite DB ships an FTS5 virtual table over `name + signature`.
Queries like "rate limiting middleware" hit this layer. Cheap, no embeddings.

```sql
CREATE VIRTUAL TABLE symbols_fts USING fts5(
  name, signature, file, repo,
  content='symbols', content_rowid='id'
);
```

### Layer 3 — Relation graph

Built from the workspace manifest. Each repo declares what it `publishes` and
`consumes`:

```yaml
- name: auth-service
  publishes: [openapi/auth.yaml]
  consumes: []

- name: user-api
  consumes: [auth-service]
```

We turn that into a directed graph. The retriever uses it for two things:

- **Anchor expansion** — "user mentioned `auth-service`" → "also consider
  user-api and admin-frontend".
- **Impact analysis** — `impactedBy(graph, repoName)` returns the transitive
  consumer set, exactly the repos a refactor needs to touch.

This layer is what prevents partial migrations. Without it, a 20-repo
refactor becomes a guessing game.

### Layer 4 — Embeddings (optional)

For natural-language docs (PRDs, ADRs, READMEs) symbol+FTS isn't enough.
Embeddings let queries like "where do we discuss why we chose Postgres over
MongoDB?" hit. We expose an `Embedder` interface so you can plug in:

- Voyage / OpenAI / Cohere (cloud)
- BGE / INSTRUCTOR via `@xenova/transformers` (local)
- Any provider with `.embed(texts: string[]) → number[][]`

Default impl is a hash-vector stub so the POCs run without a provider.

## How the retriever orchestrates layers

`Retriever.retrieve({ text, anchors, repos, budget })`:

```
1. For each anchor:
   a. Look up exact symbol (Layer 1) → read ±20 lines around it
   b. Append to context buffer if budget allows
2. For the task text:
   a. FTS5 search (Layer 2) → top 12 hits
   b. Read neighborhoods, append until budget hits
3. For each anchor that's a repo name:
   a. Walk the relation graph (Layer 3) → list impacted repos
   b. Append a "repos that depend on X" section
4. (optional) For task text:
   a. Embeddings search (Layer 4) over docs
   b. Append top-k snippets
5. Prepend a workspace overview (always cheap, always useful)
6. Return { context, files: [...], repos: [...] }
```

The output is a *bounded* string with a list of source citations. The agent
sees the context; the user can audit it via the `context.snapshot.md` file
the POC writes.

## Scaling characteristics

| N repos | Files | Symbols | Index time | Lookup p99 | Memory |
|--------:|------:|--------:|-----------:|-----------:|-------:|
| 3       | ~10   | ~30     | < 100 ms   | < 1 ms     | ~5 MB  |
| 10      | ~5k   | ~15k    | ~5 s       | < 5 ms     | ~30 MB |
| 20      | ~30k  | ~80k    | ~30 s      | < 10 ms    | ~80 MB |
| 50      | ~150k | ~400k   | ~3 min     | < 30 ms    | ~250 MB |

The 20-repo case is the sweet spot the design targets. Above 50 repos you
want to shard the SQLite DB by team or domain.

## Why this beats RAG-on-everything

The lazy approach to multi-repo context is "embed everything, vector-search,
top-k chunks". Three problems:

1. **Embeddings hallucinate relevance** — semantic similarity ≠ "this is the
   file you need to edit". A doc that *talks about* `user_id` ranks the same
   as the file that *defines* it.
2. **No graph awareness** — embeddings don't know that `user-api` consumes
   `auth-service`. They retrieve based on text similarity, not architecture.
3. **Cost** — embedding 30k files costs real money and 90 % of queries don't
   need that fidelity. Symbols + FTS handle them in a few milliseconds.

Embeddings are layer 4 for a reason: they're the most expensive and the
least precise. You only reach for them when the cheaper layers don't have
the answer.

## What this enables that other tools don't

- **Coherent cross-repo refactors** — see POC 1→N
- **Impact analysis before edit** — "if I change this, what else moves?"
- **Per-repo PR generation** — each impacted repo gets its own patch file
- **Auditable retrieval** — every run writes its `context.snapshot.md`,
  so you can prove what the agent did and didn't see
