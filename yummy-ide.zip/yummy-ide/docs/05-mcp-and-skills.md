# 05 — MCP and Skills: the integration layer

> *How any tool plugs in, how skills compose, and how to ship your own.*

## Two integration surfaces

```
┌──────────────────────────────────────────────────┐
│ User intent                                      │
└──────────────┬───────────────────────────────────┘
               ▼
┌──────────────────────────────────────────────────┐
│ Skill router  ←──reads──  SKILL.md frontmatter   │ ← what to DO
└──────────────┬───────────────────────────────────┘
               ▼
┌──────────────────────────────────────────────────┐
│ Agents + Orchestrator                            │
└──────────────┬───────────────────────────────────┘
               ▼
┌──────────────────────────────────────────────────┐
│ MCP manager  ←──reads──  mcp.config.json         │ ← what to USE
└──────────────────────────────────────────────────┘
```

**Skills** are the *playbook* — they describe a workflow.
**MCP servers** are the *tools* — they describe capabilities.

A skill can declare which MCP tools it's allowed to call. Without that
allow-list, tool selection is fuzzy and prone to misuse. With it, security
and predictability come for free.

## Adding a new skill

A skill is a folder with one file:

```
skills/
└── my-skill/
    └── SKILL.md
```

Frontmatter is YAML:

```yaml
---
name: my-skill
description: |
  When this skill should be loaded. The router reads this string.
  Be specific: list trigger phrases, the user-facing intent, and
  what kind of output the user wants.
tags: [category-1, category-2]
agents: [coder, reviewer]
allowed_mcp_tools: [filesystem, github]
invokes: [code-review]
license: MIT
---

# Skill body

The actual playbook. Markdown. Show the agent the steps, the format, the
anti-patterns. Treat this as the prompt the agent will follow.
```

Drop the folder into one of:
- `<workspace>/.skills/` (project-scoped, version-controlled)
- `~/.yummy/skills/` (user-scoped)
- `<extension>/skills/` (built-in, ships with the IDE)

Project beats user beats built-in on id collision. No reload needed in the
CLI — every run scans. In the extension, run `Yummy: Reload skills`.

## Adding a new MCP server

Edit `mcp.config.json` at your workspace root:

```json
{
  "servers": [
    {
      "name": "asana",
      "type": "url",
      "url": "https://mcp.asana.com/sse",
      "skills": ["sdd"],
      "enabled": true
    },
    {
      "name": "filesystem",
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "."],
      "skills": [],
      "enabled": true
    }
  ]
}
```

Two transport types:

### URL servers
Forwarded directly to the Anthropic API via the `mcp_servers` request
parameter. The model invokes the server's tools server-side; the responses
flow back inline. **No local code execution** — good for hosted SaaS APIs
(Asana, Linear, Notion, GitHub).

### Stdio servers
Spawned locally via `@modelcontextprotocol/sdk`. Their tools become native
Anthropic tools (function calling). **Stays on your machine** — good for
filesystem, databases, and internal tools you don't want hitting an external
API.

## Compatibility matrix

| Skill format | Yummy | Claude Code | Cursor | Codex | OpenCode |
|---|:-:|:-:|:-:|:-:|:-:|
| `SKILL.md` with YAML frontmatter | ✓ | ✓ | ✓ | ✓ | ✓ |
| `agents:` field | ✓ | — | partial | ✓ | — |
| `allowed_mcp_tools:` field | ✓ | ✓ | ✓ | ✓ | ✓ |
| `invokes:` field (skill composition) | ✓ | partial | partial | ✓ | partial |

Bottom line: skills you ship for Yummy work nearly everywhere. Skills built
for Claude Code or OpenCode load into Yummy with no modifications.

## Curating a skill library

For a team of 10+ engineers managing 20 repos, you want roughly:

- **5–10 universal skills** committed to the repo:
  `sdd`, `code-review`, `multi-repo-refactor`, `adr-writer`,
  `migration-orchestrator`, plus team-specific ones (`db-migration`,
  `pr-template`, `incident-response`).
- **2–5 per-domain skills**: `ml-experiment`, `terraform-change`,
  `mobile-release`. These live in repos that need them, scoped via
  `<repo>/.skills/`.
- **Personal skills** in `~/.yummy/skills/` for individual workflows.

The router cuts hundreds of skills down to 1–3 per request, so you don't
pay a context tax for shipping more.

## Anti-patterns

- ❌ Skills with vague descriptions ("helps with code") — the router can't
  match them, they sit unused.
- ❌ Skills longer than 200 lines — split into composed skills via `invokes:`.
- ❌ MCP servers with no skill scoping — the model picks the wrong tools at
  random.
- ❌ Telling the agent "use this MCP" in the skill body without actually
  declaring it in `allowed_mcp_tools` — the manager strips it.
