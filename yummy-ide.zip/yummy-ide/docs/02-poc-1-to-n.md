# 02 — POC 1 → N: cross-repo refactor

> *Same five agents, but now with workspace-aware context and a different chain.*

## The job

You have three repos that share a contract:

```
auth-service  ──publishes──▶  Principal { user_id, … }
                                  │
                                  ├──▶ user-api (consumes)
                                  └──▶ admin-frontend (consumes)
```

The task: rename `user_id` → `userId` everywhere, coherently, without
breaking the consumers.

## Run it

```bash
# Offline:
pnpm --filter @yummy/poc-1-to-n run start -- \
  --workspace ./packages/poc-1-to-n/workspace.yummy.yml \
  --task "rename field user_id → userId across all consumers" \
  --anchors user_id,Principal \
  --dry-run

# Live:
export ANTHROPIC_API_KEY=sk-ant-…
pnpm --filter @yummy/poc-1-to-n run start -- \
  --workspace ./packages/poc-1-to-n/workspace.yummy.yml \
  --task "rename field user_id → userId across all consumers" \
  --anchors user_id,Principal
```

## What happens, step by step

### Step 1 · Load the workspace manifest

The runner reads `workspace.yummy.yml` and builds a relation graph:

```
● workspace  "yummy-fixtures"  ·  3 repo(s)
  - auth-service     role=service   impacted-by-changes-here=[user-api,admin-frontend]
  - user-api         role=api       impacted-by-changes-here=[admin-frontend]
  - admin-frontend   role=frontend  impacted-by-changes-here=[]
```

Notice: `auth-service` is the contract owner, so a change there fans out
transitively. `admin-frontend` is a leaf — changes here are local.

### Step 2 · Index every repo into a code map

```
● indexing
  indexed 7 file(s), 28 symbol(s) in 84ms → ./packages/poc-1-to-n/.yummy.db
```

The code map is a SQLite database with three tables:
- `symbols` — every exported function, class, type, interface
- `symbols_fts` — FTS5 virtual table for fuzzy search
- `imports` — every `import` statement (powers the consumer-graph)

This is the same shape you'd use for 20 repos — it just has more rows.

### Step 3 · Hybrid retrieval

Given the task and anchors `[user_id, Principal]`, the retriever:
1. Looks up each anchor as an exact symbol → pulls the source neighborhoods.
2. Runs the task as an FTS5 query → pulls fuzzy matches.
3. Walks the relation graph → adds a "repos that depend on X" section.
4. Prepends a workspace overview so the agent always sees the big picture.

All under a hard char budget (default 12000). When it hits the budget it stops.

### Step 4 · Brownfield agent flow

Different from greenfield: no BA — the task is given. We jump to:

```
Architect → Coder ⇄ Reviewer (up to 3 rounds) → Doc
```

The Architect's job here isn't to design from scratch but to produce a
**change set table**: which files in which repos get edited, in what order.
The Coder then emits one file per row with the repo-prefixed path so the
runner can split them into per-repo patches.

### Step 5 · Materialize plan + patches

```
● writing plan + patches  → ./out
  + ./out/plan.md                    ← the full architect/coder/reviewer output
  + ./out/auth-service.patch.md      ← only blocks attributed to this repo
  + ./out/user-api.patch.md
  + ./out/admin-frontend.patch.md
  + ./out/context.snapshot.md        ← exact context the agents saw (audit trail)
```

The "plan + patches + audit-trail" output shape is deliberate: at 20-repo
scale, you don't want a button that just commits the change. You want a
human-reviewable plan that maps cleanly onto N pull requests.

## Why this shape works at scale

| Scaling concern | How POC 1→N handles it |
|---|---|
| Context window blows up with N repos | Retriever caps at byte budget; only neighborhoods, never full files |
| Indexing 20 repos is slow | SQLite + WAL + 8-way parallelism (`p-limit`); typically < 5s for ~10k files |
| LLM picks the wrong repos to touch | Anchors + relation graph constrain the search; reviewer cross-checks |
| Partial migration risk | The plan is split into per-repo patches; merge order is explicit |
| Audit / compliance | `context.snapshot.md` records exactly what the agent saw |
| Re-runs need to be fast | Code map is persistent; only changed files re-index |

## Extending to 20+ repos

The `examples/workspace.yummy.yml` shows what a real 20-repo manifest looks
like. The system has no hard cap on `repos:` length; the only thing that
changes is:

- **Index time** — grows roughly linearly with file count. With WAL and
  8-way parallelism, 20 repos ≈ 30k files indexes in ~30s on a laptop.
- **Retrieval recall** — for vague tasks, you may want to add the embeddings
  layer (`context/embeddings.ts`) so semantic queries hit. The interface is
  already pluggable; just install a real embedder.
