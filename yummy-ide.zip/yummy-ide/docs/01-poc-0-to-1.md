# 01 — POC 0 → 1: prompt to working code

> *What it does, why it's structured this way, what to look for when it runs.*

## The job

Take a single prompt — `"build magic-link login with 15-min TTL and rate limiting"` —
and produce a folder on disk containing:

- `docs/prd.md` — Product Requirements
- `docs/architecture.md` — Design + ADRs
- `src/auth/magic-link.ts` (and friends) — Implementation
- `docs/review.md` — Reviewer findings
- `README.md`, `CHANGELOG.md`, `docs/api/*.md` — Docs

…by routing the prompt through five agents in sequence, with a Coder ⇄ Reviewer
reflexion loop in the middle.

## Run it

```bash
# Offline (canned responses, no API key needed):
pnpm --filter @yummy/poc-0-to-1 run start -- \
  "build magic-link login with 15-min TTL and rate limiting" \
  --dry-run --out ./out/magic-link

# Live (with an API key):
export ANTHROPIC_API_KEY=sk-ant-…
pnpm --filter @yummy/poc-0-to-1 run start -- \
  "build magic-link login with 15-min TTL and rate limiting" \
  --out ./out/magic-link
```

## What you'll see

```
┌────────────────────────────┐
│  POC 0 → 1  ·  DRY-RUN     │
└────────────────────────────┘

prompt:  build magic-link login with 15-min TTL and rate limiting
out:     ./out/magic-link

loaded 5 skill(s): sdd, code-review, multi-repo-refactor, adr-writer, migration-orchestrator
router picked: sdd, code-review, adr-writer

── ba ──
ba> # PRD · build magic-link login with 15-min TTL and rate limiting
…

── architect ──
architect> # Architecture · proposed
…

── coder ⇄ reviewer  (round 1) ──
coder> ```ts
…
reviewer> ## Review
…

── doc ──
doc> # Magic-Link Login
…

┌────────────────────────────┐
│  DONE in 2.3s · 5 file(s)  │
└────────────────────────────┘
  + docs/prd.md
  + docs/architecture.md
  + docs/review.md
  + src/auth/magic-link.ts
  + docs/README.md
```

## Why this shape

### Why five agents and not one big prompt?

A single 8000-token prompt that asks for "PRD + design + code + tests + review"
collapses the gates. The model jumps to code because code is what was asked
for. Splitting forces each gate to be defended on its own merits — and lets
us swap agents per gate (cheaper Sonnet for the BA, Opus for the Reviewer).

### Why reflexion only between Coder and Reviewer?

Because that's where the cost of being wrong is concrete: a security policy
violation in the code is something the Reviewer can name precisely. Forcing
the Coder to rewrite is cheaper than forcing a human to read 200 lines twice.

We cap rounds at 2–3 to avoid infinite loops; if the Reviewer is still
asking for changes after that, you have a design problem, not a code
problem — escalate.

### Why write files via "first line is path" convention?

Because it's robust to the model's natural output (it already loves writing
`// path/to/file.ts` at the top of code blocks) and it survives partial
streaming — we can extract files even from a truncated response.

## Extending

- Want a different chain? Pass a custom `flow: OrchestratorStep[]` to
  `Orchestrator.run()`.
- Want to plug a different LLM? `@yummy/core` exposes `Claude` via a narrow
  interface — swap with any provider that supports tool-use streaming.
- Want non-code outputs? Add a skill (e.g. `pptx`) and an agent that knows
  how to invoke it. The router will pick it up next run.
