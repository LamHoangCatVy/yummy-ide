# 04 — Forking VS Code

> *How to ship Yummy as a standalone desktop IDE the same way Cursor did.*

## TL;DR

VS Code's source is MIT-licensed at [microsoft/vscode](https://github.com/microsoft/vscode).
The *binaries* Microsoft distributes (the thing on the App Store, with the
"Visual Studio Code" name and the blue ribbon icon) are **not** redistributable
under that license. To ship a fork:

1. Clone `microsoft/vscode`.
2. **Rename the product** — change `product.json` to your name, your icon,
   your update channel, your telemetry endpoint (or none).
3. Replace the **proprietary marketplace gallery** if you want extension
   compatibility — point at OpenVSX or your own server.
4. Bundle Yummy as a **built-in extension** so users get it out of the box.
5. Build platform installers via the existing `gulp vscode-<platform>` targets.

Cursor, VSCodium, Windsurf, and Theia (loosely) all do variants of this.

## What `scripts/fork-vscode.sh` does

The bundled script automates 90 % of the work:

```bash
bash scripts/fork-vscode.sh
```

Steps:
1. `git clone --depth 1 microsoft/vscode ./yummy-ide-fork` (~150 MB)
2. Apply `scripts/brand.patch` which:
   - rewrites `product.json` (`nameShort`, `nameLong`, `applicationName`,
     `dataFolderName`, `licenseUrl`, `updateUrl`, `extensionsGallery` →
     OpenVSX, telemetry endpoints → none)
   - replaces icons under `resources/` with placeholders from `branding/`
   - changes the `product.json` `builtInExtensions` to include
     `@yummy/extension`
3. Copies the Yummy extension into `extensions/yummy/` (built form).
4. Prints next-step instructions for `yarn && yarn watch && yarn run code`.

## What stays the same

- All extensions installed by the user — your fork keeps loading them.
- All keybindings and commands.
- The "Open Folder", terminal, source control, debugger.
- LSP, DAP, Remote SSH (Yummy can use these unchanged).

## What you must change before redistributing

| Thing | Why |
|---|---|
| Product name + icon | "Visual Studio Code" is a Microsoft trademark. |
| Telemetry endpoint | Microsoft's endpoint is theirs. Use your own or none. |
| Update channel | Same — must point at *your* update server. |
| Marketplace gallery | The Microsoft Marketplace ToS forbids non-Microsoft clients. Use OpenVSX. |
| `product.json` `crashReporter` | Don't ship Microsoft's URL. |

## What you should also change

- **Proprietary fonts** ("Cascadia Code" is permissive; ship it).
- **Default extensions list** — pre-bundle Yummy and remove things you don't
  need (Git is core; the live-share preview probably isn't).
- **Welcome page** — tell users what's different about your fork.

## Disclaimer

This is technical not legal advice. The license is permissive; the trademarks
and binary distribution rights are not. Cursor publishes a thoughtful
[note on this](https://www.cursor.com/) — read it before you ship.

## Build size and signing

- Linux: AppImage / .deb / .rpm — built by `yarn gulp vscode-linux-x64-build-deb`
- macOS: `.dmg` — needs an Apple Developer ID for notarization (~$99/yr)
- Windows: `.exe` installer — needs an EV cert for SmartScreen reputation

Plan ~1 GB per platform installer; building all three on CI takes ~30 min.

## Alternative: don't fork, ship as an extension

If forking feels heavy, ship `@yummy/extension` to the marketplace and call
it a day. You give up the brand and the install experience but you skip
all the build infrastructure. Many products start here and only fork once
they've validated the value prop.
