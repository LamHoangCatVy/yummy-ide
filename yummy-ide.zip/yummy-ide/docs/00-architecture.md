# 00 — Architecture overview

> *How the pieces fit, and what each one is responsible for.*

```
┌──────────────────────────────────────────────────────────────────┐
│                         HOSTS                                    │
│  ┌──────────────────────┐   ┌──────────────────────┐             │
│  │ VS Code extension    │   │ CLI (yummy …)        │             │
│  │ (sidebar webview,    │   │ Interactive REPL +   │             │
│  │  commands, inline    │   │ subcommands.         │             │
│  │  edit, tree views)   │   └──────────────────────┘             │
│  └──────────┬───────────┘            │                           │
│             ▼                        ▼                           │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │                    @yummy/core                           │    │
│  │  Skills · Agents · Orchestrator · MCP · Context engine   │    │
│  │  · LLM client (Claude SDK + dry-run mode)                │    │
│  └──────────────────────────────────────────────────────────┘    │
│             │                        │                           │
│             ▼                        ▼                           │
│  ┌──────────────────────┐   ┌──────────────────────┐             │
│  │ Anthropic API        │   │ MCP servers          │             │
│  │ (Opus 4.7, Sonnet…)  │   │ (filesystem, GitHub, │             │
│  │ + remote MCP support │   │  Linear, Postgres…)  │             │
│  └──────────────────────┘   └──────────────────────┘             │
└──────────────────────────────────────────────────────────────────┘
```

## Three design principles

1. **Hosts are interchangeable.** All product logic lives in `@yummy/core`.
   The VS Code extension is a thin host. The CLI is a thin host. A web UI
   would be a thin host. This is why the eventual VS Code fork is a packaging
   choice, not an architectural one.

2. **Skills are the primitive, not agents.** Agents are static, durable roles
   (BA, Architect, Coder, Reviewer, Doc). Skills are dynamic playbooks loaded
   into those agents per request. You don't ship a "magic-link agent" — you
   ship the `sdd` skill that any orchestrator can pick up.

3. **Context is built lazily and budgeted strictly.** Even with 20 repos in a
   workspace, a single agent call must fit in the context window. The
   retriever returns *neighborhoods of symbols*, not whole files, and stops
   the moment it hits the budget.

## The four layers in depth

### 1. Skill system

A skill is a folder with a `SKILL.md`:
```
skills/
└── sdd/
    └── SKILL.md   — frontmatter + playbook body
```

The frontmatter is what the **router** sees. The body is what the **agent**
loads after the skill is selected. This separation is what makes the system
scale to hundreds of skills without context-window pressure.

The router is itself just an LLM call: "given these descriptions, pick the
1–3 most relevant ids, reply as JSON". Cheap, deterministic enough, and
upgradeable to a fine-tuned classifier later.

### 2. Agent + orchestrator

Five concrete agents (`BA`, `Architect`, `Coder`, `Reviewer`, `Doc`). Each has:
- A system prompt tuned for its role.
- An optional set of native tools.
- Access to the union of MCP servers allowed by the skills loaded for this run.

The orchestrator runs a flow — a list of `{ type: 'agent' }` and
`{ type: 'reflexion' }` steps. Reflexion is the Coder ⇄ Reviewer loop with a
configurable max-rounds.

### 3. MCP layer

Two transports supported:
- **URL servers** are forwarded as-is to the Anthropic API via the `mcp_servers`
  request parameter. Zero local code execution.
- **Stdio servers** are spawned locally via `@modelcontextprotocol/sdk` and
  their tools are exposed as native function-calling tools. Useful for things
  like `filesystem` and `postgres` where you don't want the data leaving
  the box.

A skill can declare an `allowed_mcp_tools` allow-list; the orchestrator
intersects this with the global config before sending a request.

### 4. Multi-repo context engine

This is the most novel piece. See `03-multi-repo-context.md` for the deep dive.
At a glance:
```
workspace.yummy.yml ──→ relation graph ─┐
                                        │
   indexer  ─→  SQLite code map  ───────┼─→  retriever  ──→  agent context
                (symbols, FTS5,         │
                 imports table)         │
   (optional embeddings layer) ─────────┘
```

## Where each feature lives

| Feature | Package | File |
|---|---|---|
| Skill loader | `@yummy/core` | `skills/loader.ts` |
| Skill router | `@yummy/core` | `skills/router.ts` |
| Agent base | `@yummy/core` | `agents/base.ts` |
| 5 concrete agents | `@yummy/core` | `agents/concrete.ts` |
| Orchestrator + reflexion | `@yummy/core` | `agents/orchestrator.ts` |
| MCP manager | `@yummy/core` | `mcp/manager.ts` |
| Workspace manifest | `@yummy/core` | `context/workspace.ts` |
| Code map (SQLite) | `@yummy/core` | `context/code-map.ts` |
| Hybrid retriever | `@yummy/core` | `context/retrieval.ts` |
| Anthropic + dry-run | `@yummy/core` | `llm/claude.ts` |
| Sidebar webview | `@yummy/extension` | `views/chatView.ts` |
| Commands | `@yummy/extension` | `commands/index.ts` |
| Inline edit (⌘I) | `@yummy/extension` | `commands/index.ts` |
| Greenfield demo | `@yummy/poc-0-to-1` | `src/run.ts` |
| Brownfield demo | `@yummy/poc-1-to-n` | `src/run.ts` |
| REPL | `@yummy/cli` | `src/cli.ts` |
