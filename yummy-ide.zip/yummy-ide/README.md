# Yummy/IDE — a skill-driven, multi-agent IDE

> *A pluggable IDE that combines Claude Code's agentic loop, Cursor's inline-edit UX, Claude Cowork's task orchestration, Claude for Office's document skills, OpenCode's terminal flow, and the Yummy multi-agent SDLC chain — all built on top of (and eventually as a fork of) VS Code OSS.*

This repo is an **end-to-end implementation**: working VS Code extension, two runnable POCs (0→1 greenfield and 1→N brownfield across 20+ repos), a multi-repo context engine, MCP & SKILL.md plumbing, plus a script that forks VS Code OSS and rebrands it as `Yummy IDE`.

---

## What you get

```
yummy-ide/
├── packages/
│   ├── core/             ← shared library: skills, agents, MCP, context engine
│   ├── extension/        ← VS Code extension (sidebar chat, agent stream, skill panel)
│   ├── cli/              ← `yummy` command (terminal-first, OpenCode-style)
│   ├── poc-0-to-1/       ← prompt → 5-agent chain → working code on disk
│   └── poc-1-to-n/       ← multi-repo context + cross-repo refactor demo
├── skills/               ← SKILL.md folders (sdd, code-review, refactor, adr…)
├── docs/                 ← architecture + runbooks
│   ├── 00-architecture.md
│   ├── 01-poc-0-to-1.md
│   ├── 02-poc-1-to-n.md
│   ├── 03-multi-repo-context.md
│   ├── 04-fork-vscode.md
│   └── 05-mcp-and-skills.md
├── examples/             ← workspace.yummy.yml, mcp.config.json
└── scripts/              ← bootstrap, fork-vscode, dev
```

---

## 60-second runbook

```bash
# 0. prereqs:  Node ≥ 20, pnpm (or npm), VS Code, an Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-...

# 1. install everything
bash scripts/bootstrap.sh

# 2. POC 0 → 1: build a feature from a prompt
pnpm --filter @yummy/poc-0-to-1 run start \
  -- "build magic-link login with 15-min TTL and rate limiting" \
  --out ./out/magic-link

# 3. POC 1 → N: index 3 repos and run a cross-repo refactor
pnpm --filter @yummy/poc-1-to-n run start \
  -- --workspace examples/workspace.yummy.yml \
     --task "rename field user_id → userId across all consumers"

# 4. Run the VS Code extension
pnpm --filter @yummy/extension run dev
# then F5 in VS Code to open Extension Development Host

# 5. (Optional) Fork VS Code OSS into ./yummy-ide-fork
bash scripts/fork-vscode.sh
```

---

## The four pillars

| Pillar | What it does | Where it lives |
|---|---|---|
| **Skill-driven routing** | Every user request is matched to a `SKILL.md` (or set of them). Skill = workflow recipe + tool whitelist + system prompt. | `packages/core/src/skills/` |
| **Multi-agent orchestrator** | BA → Architect → Coder → Reviewer → Doc, each is an `Agent` with its own role/tools/checks. Reflexion loops between Coder ⇄ Reviewer until quality gates pass. | `packages/core/src/agents/` |
| **MCP-everywhere** | All external tools (filesystem, GitHub, Slack, Postgres, custom) plug in as MCP servers. Skills *whitelist* which MCP tools they can use. | `packages/core/src/mcp/` |
| **Multi-repo context engine** | A 4-layer retrieval stack (symbols → BM25 → embeddings → cross-repo relations) that scales to 20+ codebases without blowing up the context window. | `packages/core/src/context/` |

See `docs/00-architecture.md` for the full picture.

---

## Why "skill-driven" is the right primitive

A skill is a folder with one file: `SKILL.md`. Frontmatter declares *when* to load it; the body is the playbook. This is the same pattern Anthropic ships internally and the same shape adopted by Cursor, Codex, Copilot, and OpenCode.

Three things make it powerful:

1. **Discoverability is the description, not the code** — the LLM matches user intent against the frontmatter, so you can ship 200 skills and only the 1-2 needed get loaded into context.
2. **Skills compose** — `sdd` calls `code-review` calls `reflexion`. A skill is just a manifest plus links to other skills and MCP tools.
3. **Skills are portable** — drop the same folder into Claude Code, Cursor, this IDE, or a Cowork-style web app and it works.

Yummy/IDE makes skills first-class: there's a sidebar marketplace, a command palette router, and a per-skill execution sandbox.

---

## Two POCs, two trajectories

**POC 0→1** demonstrates *greenfield velocity*: a single prompt becomes PRD → architecture → implementation → review → docs, written to disk. Run it on an empty folder and watch a real feature appear.

**POC 1→N** demonstrates *brownfield safety*: it indexes three small but interconnected repos (auth-service, user-api, admin-frontend) and performs a refactor that touches all three coherently — using the multi-repo context engine to plan the change before writing it. This same engine scales to 20+ repos via the workspace manifest.

---

## The endgame: forking VS Code

`scripts/fork-vscode.sh` clones [microsoft/vscode](https://github.com/microsoft/vscode) (MIT-licensed), applies a brand patch (name, icons, telemetry off), bundles the extension as built-in, and produces a desktop app named **Yummy IDE**. This is the same path Cursor took. See `docs/04-fork-vscode.md` for the legal/branding details.

---

## License

MIT. Skills under `skills/` may carry their own licenses; check each `SKILL.md`.
