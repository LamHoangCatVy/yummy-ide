#!/usr/bin/env node
/**
 * POC 0 → 1.  The greenfield trajectory.
 *
 *   prompt  →  BA  →  Architect  →  (Coder ⇄ Reviewer)  →  Doc  →  files on disk
 *
 * Usage:
 *   pnpm --filter @yummy/poc-0-to-1 run start -- "<your prompt>" --out ./out
 *   pnpm --filter @yummy/poc-0-to-1 run start -- "<prompt>" --dry-run
 *
 * Flags:
 *   --out <dir>        where to write generated files (default: ./out/<slug>)
 *   --dry-run          force the offline canned-response mode
 *   --no-doc           skip the Doc Writer step
 *   --no-review        skip the reflexion loop (coder runs once)
 *   --skills <dir>     load skills from this folder (default: ../../skills)
 *
 * The runner streams every agent token to stdout in colour, then parses code
 * blocks out of the Coder output and writes each file to disk. The first line
 * of every code block is expected to be `// path/to/file.ts` (or `# path…`).
 */
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve, dirname, basename } from 'node:path';
import { argv, exit, stdout, env } from 'node:process';
import { fileURLToPath } from 'node:url';
import {
  Claude,
  Orchestrator,
  STANDARD_GREENFIELD_FLOW,
  loadSkills,
  SkillRegistry,
  SkillRouter,
  type OrchestratorStep,
} from '@yummy/core';

// ──────────────────────────── arg parsing ─────────────────────────────
interface Args {
  prompt: string;
  out: string;
  dryRun: boolean;
  doc: boolean;
  review: boolean;
  skillsPath?: string;
}

function parseArgs(rawArgs: string[]): Args {
  const args: Args = {
    prompt: '',
    out: '',
    dryRun: false,
    doc: true,
    review: true,
  };
  const positional: string[] = [];
  for (let i = 0; i < rawArgs.length; i++) {
    const a = rawArgs[i];
    if (a === '--dry-run') args.dryRun = true;
    else if (a === '--no-doc') args.doc = false;
    else if (a === '--no-review') args.review = false;
    else if (a === '--out') args.out = rawArgs[++i] ?? '';
    else if (a === '--skills') args.skillsPath = rawArgs[++i];
    else if (a === '--help' || a === '-h') { printHelp(); exit(0); }
    else if (a && !a.startsWith('--')) positional.push(a);
  }
  args.prompt = positional.join(' ').trim();
  if (!args.prompt) {
    printHelp();
    exit(1);
  }
  if (!args.out) args.out = resolve(process.cwd(), 'out', slugify(args.prompt).slice(0, 32));
  return args;
}

function printHelp() {
  console.error(`
yummy/poc-0-to-1  —  prompt → working code

Usage:
  pnpm --filter @yummy/poc-0-to-1 run start -- "<prompt>" [--out <dir>] [--dry-run]

Flags:
  --out <dir>     where to write generated files (default: ./out/<slug>)
  --dry-run       use canned responses (no API key required)
  --no-doc        skip Doc Writer step
  --no-review     skip the Coder ⇄ Reviewer reflexion loop
  --skills <dir>  load skills from a custom directory
`);
}

// ─────────────────────────────── colours ──────────────────────────────
const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m', blue: '\x1b[34m',
  magenta: '\x1b[35m', cyan: '\x1b[36m',
};

const AGENT_COLOR: Record<string, string> = {
  ba: C.blue,
  architect: C.magenta,
  coder: C.cyan,
  reviewer: C.yellow,
  doc: C.green,
};

// ─────────────────────────────── main ─────────────────────────────────
async function main() {
  const args = parseArgs(argv.slice(2));
  const isDry = args.dryRun || !env.ANTHROPIC_API_KEY;

  banner(`POC 0 → 1  ·  ${isDry ? 'DRY-RUN' : 'LIVE'}`);
  console.log(`${C.dim}prompt:${C.reset}  ${args.prompt}`);
  console.log(`${C.dim}out:   ${C.reset}  ${args.out}`);
  console.log();

  // 1. Load skills.  The router will pick the relevant ones.
  const skillsRoot = args.skillsPath
    ?? resolve(fileURLToPath(import.meta.url), '../../../../skills');

  const skills = await loadSkills({ workspaceRoot: skillsRoot });
  const registry = new SkillRegistry(skills);
  console.log(`${C.dim}loaded ${skills.length} skill(s):${C.reset} ${skills.map(s => s.frontmatter.name).join(', ') || '(none)'}`);

  const llm = new Claude({ dryRun: isDry });
  const router = new SkillRouter(registry, llm);
  const picked = await router.route(args.prompt, 3);
  console.log(`${C.dim}router picked:${C.reset} ${picked.map(s => s.frontmatter.name).join(', ') || '(none)'}\n`);

  // 2. Build the flow.
  let flow: OrchestratorStep[] = [...STANDARD_GREENFIELD_FLOW];
  if (!args.review) {
    flow = flow.map(s =>
      s.type === 'reflexion' ? ({ type: 'agent', id: s.coder } as OrchestratorStep) : s,
    );
  }
  if (!args.doc) flow = flow.filter(s => !(s.type === 'agent' && s.id === 'doc'));

  // 3. Wire up the orchestrator and stream events.
  const orch = new Orchestrator(llm);
  let currentAgent = '';
  orch.events.on(ev => {
    if (ev.type === 'step_start' && ev.step?.type === 'agent') {
      header(ev.step.id);
    } else if (ev.type === 'reflexion_round') {
      header(`coder ⇄ reviewer  (round ${ev.round})`);
    } else if (ev.type === 'agent_event' && ev.agentEvent) {
      const ae = ev.agentEvent;
      if (ae.type === 'start') {
        currentAgent = ae.agent;
        const c = AGENT_COLOR[ae.agent] ?? C.reset;
        stdout.write(`${c}${ae.agent}>${C.reset} `);
      } else if (ae.type === 'token') {
        stdout.write(ae.text ?? '');
      } else if (ae.type === 'finish') {
        stdout.write('\n\n');
      } else if (ae.type === 'error') {
        console.error(`\n${C.red}error in ${ae.agent}: ${ae.error}${C.reset}\n`);
      }
    }
  });

  // 4. Run.
  const t0 = Date.now();
  const outputs = await orch.run({
    goal: args.prompt,
    skills: picked,
    flow,
  });
  const elapsed = ((Date.now() - t0) / 1000).toFixed(1);

  // 5. Materialize artefacts to disk.
  const written: string[] = [];
  await mkdir(args.out, { recursive: true });

  // PRD, architecture, review, etc. → docs/
  if (outputs.ba)        written.push(...await writeText(args.out, 'docs/prd.md', outputs.ba));
  if (outputs.architect) written.push(...await writeText(args.out, 'docs/architecture.md', outputs.architect));
  if (outputs.reviewer)  written.push(...await writeText(args.out, 'docs/review.md', outputs.reviewer));

  // Coder output → parsed files
  if (outputs.coder) {
    const blocks = parseCodeBlocks(outputs.coder);
    for (const b of blocks) {
      if (!b.path) continue;
      written.push(...await writeText(args.out, b.path, b.code, b.lang));
    }
  }

  // Doc output → README, CHANGELOG, etc.
  if (outputs.doc) {
    const docBlocks = parseCodeBlocks(outputs.doc);
    if (docBlocks.length) {
      for (const b of docBlocks) {
        if (b.path) written.push(...await writeText(args.out, b.path, b.code, b.lang));
      }
    } else {
      // Doc writer didn't fence its output — dump it as one file.
      written.push(...await writeText(args.out, 'docs/README.md', outputs.doc));
    }
  }

  banner(`DONE in ${elapsed}s  ·  ${written.length} file(s) written`);
  for (const f of written) console.log(`  ${C.green}+${C.reset} ${f}`);
  console.log(`\n${C.dim}artefacts at:${C.reset} ${args.out}`);
}

// ───────────────────────── helpers ────────────────────────────────────

function banner(s: string) {
  const line = '─'.repeat(s.length + 4);
  console.log(`\n${C.bold}┌${line}┐${C.reset}`);
  console.log(`${C.bold}│  ${s}  │${C.reset}`);
  console.log(`${C.bold}└${line}┘${C.reset}\n`);
}
function header(s: string) {
  console.log(`\n${C.dim}── ${s} ──${C.reset}`);
}
function slugify(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}

interface CodeBlock { lang: string; path?: string; code: string }

/**
 * Parse fenced code blocks. The first line of each block is treated as a
 * "// path/to/file.ext" or "# path/to/file.ext" hint and stripped.
 */
function parseCodeBlocks(md: string): CodeBlock[] {
  const blocks: CodeBlock[] = [];
  const re = /```([a-zA-Z0-9_+-]*)\n([\s\S]*?)```/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(md)) !== null) {
    const lang = m[1] ?? '';
    let code = m[2] ?? '';
    // First-line path hint?
    const firstLine = code.split('\n', 1)[0] ?? '';
    let path: string | undefined;
    const pathMatch = firstLine.match(/^\s*(?:\/\/|#)\s*([\w./\-]+\.\w+)\s*$/);
    if (pathMatch) {
      path = pathMatch[1];
      code = code.slice(firstLine.length + 1); // strip header + \n
    }
    blocks.push({ lang, path, code });
  }
  return blocks;
}

async function writeText(root: string, relPath: string, body: string, _lang?: string): Promise<string[]> {
  const abs = resolve(root, relPath);
  await mkdir(dirname(abs), { recursive: true });
  await writeFile(abs, body.endsWith('\n') ? body : body + '\n', 'utf8');
  return [relPath];
}

main().catch(err => {
  console.error('\nfatal:', err);
  exit(1);
});
