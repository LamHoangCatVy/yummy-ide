/**
 * @yummy/core — primitives for a skill-driven, multi-agent IDE.
 *
 * Everything in this package is host-agnostic: it doesn't depend on VS Code,
 * Node CLIs, or any specific UI. Both the VS Code extension and the standalone
 * CLI/POCs build on top of it.
 */

export * from './skills/index.js';
export * from './agents/index.js';
export * from './mcp/index.js';
export * from './context/index.js';
export * from './llm/index.js';
export * from './utils/events.js';
