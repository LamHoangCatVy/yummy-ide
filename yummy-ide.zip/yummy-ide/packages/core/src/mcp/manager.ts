/**
 * MCP (Model Context Protocol) integration.
 *
 * Strategy:
 *  - URL-type MCP servers are forwarded directly to the Anthropic API via the
 *    `mcp_servers` request parameter — no local execution needed.
 *  - Stdio-type MCP servers are connected to via @modelcontextprotocol/sdk and
 *    their tools are exposed as native Anthropic tools (function calling).
 *
 * This dual strategy lets you mix:
 *   - Hosted MCPs: Asana, Notion, Slack, GitHub, Linear (zero-setup)
 *   - Local MCPs:  filesystem, postgres, your-own-internal-tooling
 */
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { z } from 'zod';
import type { MCPServerSpec } from '../llm/claude.js';

export const MCPConfigSchema = z.object({
  servers: z.array(z.object({
    name: z.string(),
    type: z.enum(['url', 'stdio']),
    url: z.string().optional(),
    command: z.string().optional(),
    args: z.array(z.string()).optional(),
    authToken: z.string().optional(),
    /** Allow-list: which skills can use this server. Empty = all. */
    skills: z.array(z.string()).optional(),
    enabled: z.boolean().default(true),
  })),
});

export type MCPConfig = z.infer<typeof MCPConfigSchema>;

export class MCPManager {
  private config: MCPConfig = { servers: [] };

  async loadConfig(workspaceRoot: string): Promise<MCPConfig> {
    const path = resolve(workspaceRoot, 'mcp.config.json');
    if (!existsSync(path)) return this.config;
    const raw = await readFile(path, 'utf8');
    this.config = MCPConfigSchema.parse(JSON.parse(raw));
    return this.config;
  }

  /** Servers that should be passed to a request, optionally filtered by skill ids. */
  serversFor(skillIds: string[] = []): MCPServerSpec[] {
    return this.config.servers
      .filter(s => s.enabled !== false)
      .filter(s => !s.skills || s.skills.length === 0 || skillIds.some(id => s.skills!.includes(id)))
      .map(s => ({
        type: s.type,
        name: s.name,
        url: s.url,
        command: s.command,
        args: s.args,
        authToken: s.authToken,
      }));
  }

  list(): MCPConfig['servers'] {
    return this.config.servers;
  }

  /** Add a server at runtime (e.g. user "Connect new MCP" command in IDE). */
  add(server: MCPConfig['servers'][number]): void {
    this.config.servers.push(server);
  }
}
