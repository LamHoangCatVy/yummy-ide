import { readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { resolve, dirname, basename } from 'node:path';
import { existsSync } from 'node:fs';
import { globby } from 'globby';
import matter from 'gray-matter';
import { Skill, SkillFrontmatter, SkillFrontmatterSchema } from './types.js';

export interface LoaderOptions {
  /** The IDE workspace root — we'll look in <root>/.skills/ and <root>/skills/ */
  workspaceRoot?: string;
  /** Custom search paths in addition to defaults. */
  extraPaths?: string[];
  /** If false, skip scanning ~/.yummy/skills */
  includeUserSkills?: boolean;
  /** If false, skip the bundled skills shipped with the IDE. */
  includeBuiltins?: boolean;
  /** Bundled-skill path (resolved by the host). */
  builtinPath?: string;
}

export async function loadSkills(opts: LoaderOptions = {}): Promise<Skill[]> {
  const sources: Array<{ path: string; origin: Skill['origin'] }> = [];

  if (opts.workspaceRoot) {
    for (const dir of ['.skills', 'skills']) {
      const p = resolve(opts.workspaceRoot, dir);
      if (existsSync(p)) sources.push({ path: p, origin: 'project' });
    }
  }

  if (opts.includeUserSkills !== false) {
    const userPath = resolve(homedir(), '.yummy', 'skills');
    if (existsSync(userPath)) sources.push({ path: userPath, origin: 'user' });
  }

  if (opts.includeBuiltins !== false && opts.builtinPath && existsSync(opts.builtinPath)) {
    sources.push({ path: opts.builtinPath, origin: 'builtin' });
  }

  for (const p of opts.extraPaths ?? []) {
    if (existsSync(p)) sources.push({ path: p, origin: 'project' });
  }

  const all: Skill[] = [];
  for (const src of sources) {
    const files = await globby('**/SKILL.md', {
      cwd: src.path,
      absolute: true,
      gitignore: true,
      // Don't recurse into node_modules, dist, etc.
      ignore: ['**/node_modules/**', '**/dist/**', '**/.git/**'],
    });
    for (const file of files) {
      const skill = await parseSkill(file, src.origin);
      if (skill) all.push(skill);
    }
  }

  // De-dupe by id; project > user > builtin precedence.
  const winners = new Map<string, Skill>();
  const rank: Record<Skill['origin'], number> = { project: 3, user: 2, builtin: 1 };
  for (const s of all) {
    const existing = winners.get(s.id);
    if (!existing || rank[s.origin] > rank[existing.origin]) winners.set(s.id, s);
  }
  return [...winners.values()].sort((a, b) =>
    a.frontmatter.name.localeCompare(b.frontmatter.name),
  );
}

async function parseSkill(file: string, origin: Skill['origin']): Promise<Skill | null> {
  try {
    const raw = await readFile(file, 'utf8');
    const parsed = matter(raw);
    const fmRes = SkillFrontmatterSchema.safeParse(parsed.data);
    if (!fmRes.success) {
      console.warn(`[yummy/skills] invalid frontmatter in ${file}:`, fmRes.error.message);
      return null;
    }
    const frontmatter: SkillFrontmatter = fmRes.data;
    const folder = dirname(file);
    const id = slugify(frontmatter.name) || basename(folder);
    return { id, path: folder, frontmatter, body: parsed.content.trim(), origin };
  } catch (err) {
    console.warn(`[yummy/skills] failed to read ${file}:`, err);
    return null;
  }
}

function slugify(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}
