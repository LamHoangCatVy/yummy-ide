import { z } from 'zod';

/**
 * A Skill is a folder containing a SKILL.md file. The frontmatter declares
 * *when* the skill should be loaded; the body is the playbook the agent
 * follows when the skill is active.
 *
 * Compatible with Anthropic's Agent Skills format used by Claude Code,
 * Codex, Cursor, and OpenCode.
 */
export const SkillFrontmatterSchema = z.object({
  name: z.string(),
  description: z.string(),
  /** Tags help the router pick this skill from a large library. */
  tags: z.array(z.string()).optional(),
  /** Which agents this skill is intended for. */
  agents: z.array(z.string()).optional(),
  /** MCP tools this skill is allowed to call (allowlist). */
  allowed_mcp_tools: z.array(z.string()).optional(),
  /** Sub-skills invoked by this one. */
  invokes: z.array(z.string()).optional(),
  license: z.string().optional(),
  source: z.string().optional(),
});

export type SkillFrontmatter = z.infer<typeof SkillFrontmatterSchema>;

export interface Skill {
  /** Unique slug, derived from the folder name. */
  id: string;
  /** Absolute path to the skill folder. */
  path: string;
  /** Parsed frontmatter. */
  frontmatter: SkillFrontmatter;
  /** Markdown body — the playbook itself, sans frontmatter. */
  body: string;
  /** Where the skill came from. */
  origin: 'project' | 'user' | 'builtin';
}

/** A subset of fields safe to send to webviews / external consumers. */
export interface SkillSummary {
  id: string;
  name: string;
  description: string;
  tags: string[];
  origin: Skill['origin'];
}

export function summarize(s: Skill): SkillSummary {
  return {
    id: s.id,
    name: s.frontmatter.name,
    description: s.frontmatter.description,
    tags: s.frontmatter.tags ?? [],
    origin: s.origin,
  };
}
