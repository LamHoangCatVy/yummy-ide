import { Skill, SkillSummary, summarize } from './types.js';

/**
 * Holds the loaded skill set in memory and provides lookup + simple search.
 * Search is intentionally cheap (substring + token overlap) — the actual
 * intent → skill matching is done by an LLM via {@link SkillRouter}.
 */
export class SkillRegistry {
  private byId = new Map<string, Skill>();

  constructor(initial: Skill[] = []) {
    for (const s of initial) this.byId.set(s.id, s);
  }

  upsert(skill: Skill): void {
    this.byId.set(skill.id, skill);
  }

  remove(id: string): boolean {
    return this.byId.delete(id);
  }

  get(id: string): Skill | undefined {
    return this.byId.get(id);
  }

  byName(name: string): Skill | undefined {
    for (const s of this.byId.values()) {
      if (s.frontmatter.name === name) return s;
    }
    return undefined;
  }

  list(): Skill[] {
    return [...this.byId.values()];
  }

  summaries(): SkillSummary[] {
    return this.list().map(summarize);
  }

  /** Cheap full-text-ish search over name + description + tags. */
  search(query: string): Skill[] {
    const q = query.toLowerCase().trim();
    if (!q) return this.list();
    const tokens = q.split(/\s+/);
    return this.list()
      .map(s => ({ s, score: score(s, tokens) }))
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .map(({ s }) => s);
  }
}

function score(s: Skill, tokens: string[]): number {
  const hay = [
    s.frontmatter.name,
    s.frontmatter.description,
    ...(s.frontmatter.tags ?? []),
  ].join(' ').toLowerCase();
  let score = 0;
  for (const t of tokens) if (hay.includes(t)) score += 1;
  return score;
}
