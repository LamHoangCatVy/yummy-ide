import { Claude } from '../llm/claude.js';
import { Skill, SkillSummary, summarize } from './types.js';
import { SkillRegistry } from './registry.js';

/**
 * Given a user prompt, pick the best 1-3 skills to activate.
 *
 * We do this in two stages:
 *   1. Cheap lexical filter: cut from N skills to top ~12 candidates.
 *   2. LLM re-rank: send the candidate descriptions and let Claude pick.
 *
 * This is the same pattern as the Anthropic Skills feature: the LLM only sees
 * the *descriptions* of available skills, not their bodies. The bodies are
 * loaded into the working agent's prompt only after a skill is selected.
 */
export class SkillRouter {
  constructor(private registry: SkillRegistry, private llm: Claude) {}

  async route(prompt: string, k: number = 3): Promise<Skill[]> {
    const all = this.registry.list();
    if (all.length === 0) return [];

    // Stage 1 — keep this cheap, no API call.
    const candidates = all.length > 12
      ? this.registry.search(prompt).slice(0, 12) || all.slice(0, 12)
      : all;
    const candidateSummaries = candidates.map(summarize);

    // If there are very few candidates, skip the LLM call.
    if (candidates.length <= k) return candidates;

    // Stage 2 — let Claude rank. Requesting only ids keeps the response tiny.
    const result = await this.llm.complete({
      system: ROUTER_SYSTEM,
      messages: [
        {
          role: 'user',
          content: this.routerUserMessage(prompt, candidateSummaries, k),
        },
      ],
      maxTokens: 256,
    });

    const ids = parseIds(result.text);
    const picked = ids
      .map(id => candidates.find(c => c.id === id))
      .filter((s): s is Skill => !!s);

    return picked.length ? picked : candidates.slice(0, k);
  }

  private routerUserMessage(prompt: string, candidates: SkillSummary[], k: number): string {
    const list = candidates
      .map(c => `- id: ${c.id}\n  name: ${c.name}\n  description: ${c.description}`)
      .join('\n');
    return `User prompt:
"""
${prompt}
"""

Available skills:
${list}

Pick up to ${k} skills whose playbooks would help an agent fulfill this request.
Reply with ONLY a JSON array of skill ids, no prose. Example: ["sdd","code-review"]`;
  }
}

const ROUTER_SYSTEM = `You are a skill router.
You map user requests to a small set of relevant skills.
You never invent skill ids. You return JSON only.`;

function parseIds(text: string): string[] {
  // Tolerant of code fences / extra whitespace.
  const m = text.match(/\[[\s\S]*?\]/);
  if (!m) return [];
  try {
    const arr = JSON.parse(m[0]);
    return Array.isArray(arr) ? arr.filter((x): x is string => typeof x === 'string') : [];
  } catch {
    return [];
  }
}
