/**
 * Thin wrapper around @anthropic-ai/sdk that:
 *   1. exposes a streaming async-iterable interface
 *   2. supports MCP servers via the messages.create({ mcp_servers: [...] }) param
 *   3. supports tool-use (function calling)
 *   4. has a `dryRun` mode that returns canned responses — so the POCs can be
 *      demoed without burning credits or needing a key.
 */
import Anthropic from '@anthropic-ai/sdk';
import type { Message, MessageParam, Tool, ToolUseBlock } from '@anthropic-ai/sdk/resources/messages';

export interface MCPServerSpec {
  type: 'url' | 'stdio';
  name: string;
  url?: string;          // for type: 'url'
  command?: string;      // for type: 'stdio'
  args?: string[];
  authToken?: string;
}

export interface CompleteParams {
  system: string;
  messages: MessageParam[];
  tools?: Tool[];
  mcpServers?: MCPServerSpec[];
  model?: string;
  maxTokens?: number;
  /** Called for each text chunk during streaming. */
  onText?: (chunk: string) => void;
  /** Called when a tool_use block appears in the stream. */
  onToolUse?: (block: ToolUseBlock) => void;
}

export interface CompleteResult {
  text: string;
  toolUses: ToolUseBlock[];
  /** raw final message for callers that need stop_reason, usage, etc. */
  raw: Message;
  /** token usage if reported by the API */
  usage?: { input: number; output: number };
}

export interface ClaudeOptions {
  apiKey?: string;        // falls back to ANTHROPIC_API_KEY
  defaultModel?: string;
  dryRun?: boolean;       // canned responses, no network
}

export class Claude {
  private client?: Anthropic;
  private defaultModel: string;
  private dryRun: boolean;

  constructor(opts: ClaudeOptions = {}) {
    this.defaultModel = opts.defaultModel ?? 'claude-opus-4-7';
    this.dryRun = opts.dryRun ?? !process.env.ANTHROPIC_API_KEY;
    if (!this.dryRun) {
      this.client = new Anthropic({ apiKey: opts.apiKey ?? process.env.ANTHROPIC_API_KEY });
    }
  }

  async complete(params: CompleteParams): Promise<CompleteResult> {
    if (this.dryRun) return this.cannedResponse(params);

    const stream = this.client!.messages.stream({
      model: params.model ?? this.defaultModel,
      max_tokens: params.maxTokens ?? 4096,
      system: params.system,
      messages: params.messages,
      tools: params.tools,
      // mcp_servers is supported by the API as a top-level param.
      // @ts-expect-error — typings lag the runtime API
      mcp_servers: (params.mcpServers ?? []).map(s => ({
        type: s.type,
        name: s.name,
        url: s.url,
        command: s.command,
        args: s.args,
        authorization_token: s.authToken,
      })).filter(s => s.type === 'url'),  // SDK currently supports url-type only
    });

    let collectedText = '';
    const toolUses: ToolUseBlock[] = [];

    stream.on('text', (chunk) => {
      collectedText += chunk;
      params.onText?.(chunk);
    });
    stream.on('contentBlock', (block) => {
      if (block.type === 'tool_use') {
        toolUses.push(block);
        params.onToolUse?.(block);
      }
    });

    const raw = await stream.finalMessage();
    return {
      text: collectedText,
      toolUses,
      raw,
      usage: raw.usage
        ? { input: raw.usage.input_tokens, output: raw.usage.output_tokens }
        : undefined,
    };
  }

  /** Deterministic canned responses for offline demos. */
  private cannedResponse(p: CompleteParams): Promise<CompleteResult> {
    const lastUser = [...p.messages].reverse().find(m => m.role === 'user');
    const userText = typeof lastUser?.content === 'string'
      ? lastUser.content
      : JSON.stringify(lastUser?.content);

    const sysFingerprint = p.system.slice(0, 80).toLowerCase();
    let text: string;
    if (sysFingerprint.includes('business analyst')) {
      text = canned.ba(userText);
    } else if (sysFingerprint.includes('architect')) {
      text = canned.architect(userText);
    } else if (sysFingerprint.includes('implementer') || sysFingerprint.includes('coder')) {
      text = canned.coder(userText);
    } else if (sysFingerprint.includes('reviewer')) {
      text = canned.reviewer(userText);
    } else if (sysFingerprint.includes('doc')) {
      text = canned.doc(userText);
    } else {
      text = `[dry-run] system="${p.system.slice(0, 40)}…" → simulated response for: ${userText.slice(0, 200)}`;
    }

    // Stream it character by character so callers' onText handlers fire naturally.
    if (p.onText) {
      for (const ch of text) p.onText(ch);
    }

    const fakeMessage: Message = {
      id: 'msg_dryrun',
      type: 'message',
      role: 'assistant',
      model: this.defaultModel,
      content: [{ type: 'text', text, citations: [] }],
      stop_reason: 'end_turn',
      stop_sequence: null,
      usage: { input_tokens: 0, output_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: 0, server_tool_use: null, service_tier: null },
    } as unknown as Message;

    return Promise.resolve({ text, toolUses: [], raw: fakeMessage });
  }
}

/** Canned responses good enough to demo the agent flow without a key. */
const canned = {
  ba: (req: string) => `# PRD · ${truncate(req, 60)}

## Problem
${truncate(req, 200)}

## Goals
- Reduce friction in the primary user flow.
- Maintain compliance with our security policy (SEC-014).

## User stories
- As a returning user, I want to act with one input.
- As a new user, I want a session created without a password.
- As an admin, I want abusive use blocked.

## Constraints
- Token TTL ≤ 15 minutes.
- Rate limit 5 requests / email / hour.
- Use existing EmailProvider port.

## Out of scope
- SSO migration (separate epic).
`,
  architect: () => `# Architecture · proposed

## Components
- \`MagicLinkService\`        — orchestrates issue + verify
- \`TokenStore\`     (port)    — Redis impl with EX
- \`EmailPort\`      (port)    — SES impl, templated send
- \`RateLimiter\`    (port)    — sliding window, IP+email key

## Sequence
1. POST /auth/magic-link  → issue token, mail link
2. GET  /auth/verify?t=…  → consume token, mint session

## Decisions (ADR)
- ADR-007: hex token over JWT (server-revocable).
- ADR-008: TTL via store EX, not in payload.
`,
  coder: () => `\`\`\`ts
// src/auth/magic-link.ts — generated by @coder
import { randomBytes } from 'crypto';
import type { EmailPort, TokenStore, RateLimiter } from './ports.js';

export async function sendMagicLink(
  email: string,
  email_port: EmailPort,
  store: TokenStore,
  rate: RateLimiter,
): Promise<void> {
  await rate.check({ key: \`magic:\${email}\`, max: 5, window: '1h' });

  const token   = randomBytes(32).toString('hex');
  const expires = Date.now() + 15 * 60 * 1000; // SEC-014: ≤ 15min
  await store.put(token, { email, expires });

  const link = \`https://app.yummy.dev/auth/verify?t=\${token}\`;
  await email_port.send({
    to: email,
    subject: 'Your sign-in link · valid 15 minutes',
    body: \`Click to sign in: \${link}\`,
  });
}
\`\`\`
`,
  reviewer: () => `## Review

**0 blocking issues found.**

Findings:
- ✓ TTL = 15min — satisfies SEC-014.
- ✓ Rate limit applied at entry — fail-fast on abuse.
- i Suggestion: extract \`sendMagicLink\` behind a \`MagicLinkService\` class so the verify path can share state.
- i Suggestion: log token-issued events to the audit pipeline.

Test coverage: ports are mockable; recommend adding a property test that the same token can't be consumed twice.

VERDICT: APPROVE with non-blocking suggestions.
`,
  doc: () => `# Magic-Link Login

Sign in with just your email — we'll send you a one-time link valid for 15 minutes.

## How it works
1. Enter your email.
2. Check your inbox and click the link.
3. You're in — no password required.

## Security
- Links expire after 15 minutes.
- Each link works exactly once.
- We rate-limit requests to prevent abuse.
`,
};

function truncate(s: string, n: number): string {
  return s.length <= n ? s : s.slice(0, n - 1) + '…';
}
