/**
 * Minimal typed event emitter. Used by the orchestrator to stream agent
 * progress to whatever UI happens to be hosting us (extension, CLI, web).
 */
export type Listener<T> = (event: T) => void;

export class Emitter<T> {
  private listeners = new Set<Listener<T>>();

  on(fn: Listener<T>): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  emit(event: T): void {
    for (const fn of this.listeners) {
      try {
        fn(event);
      } catch (err) {
        // Never let one listener break the chain.
        console.error('[yummy/event] listener threw', err);
      }
    }
  }

  clear(): void {
    this.listeners.clear();
  }
}
