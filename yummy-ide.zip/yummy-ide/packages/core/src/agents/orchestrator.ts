import { Agent, AgentEvent } from './base.js';
import { Claude, MCPServerSpec } from '../llm/claude.js';
import { Skill } from '../skills/types.js';
import { Emitter } from '../utils/events.js';
import { allAgents } from './concrete.js';

export type OrchestratorStep =
  | { type: 'agent'; id: string }
  | { type: 'reflexion'; coder: string; reviewer: string; maxRounds?: number };

export interface OrchestratorJob {
  goal: string;
  skills: Skill[];
  /** The chain of steps to execute. */
  flow: OrchestratorStep[];
  /** MCP servers active for the whole job. */
  mcpServers?: MCPServerSpec[];
  /** Codebase / multi-repo context to inject into every agent. */
  context?: string;
}

export interface OrchestratorEvent {
  type:
    | 'job_start'
    | 'step_start'
    | 'agent_event'
    | 'step_end'
    | 'reflexion_round'
    | 'job_end';
  step?: OrchestratorStep;
  agent?: string;
  agentEvent?: AgentEvent;
  round?: number;
  output?: string;
}

export class Orchestrator {
  public readonly events = new Emitter<OrchestratorEvent>();
  private agents: ReturnType<typeof allAgents>;
  private extraAgents = new Map<string, Agent>();

  constructor(private llm: Claude) {
    this.agents = allAgents(llm);
    // Bridge each agent's stream into the orchestrator's event stream.
    for (const [, ag] of Object.entries(this.agents)) {
      ag.events.on(ev => this.events.emit({ type: 'agent_event', agent: ag.id, agentEvent: ev }));
    }
  }

  registerAgent(agent: Agent): void {
    this.extraAgents.set(agent.id, agent);
    agent.events.on(ev => this.events.emit({ type: 'agent_event', agent: agent.id, agentEvent: ev }));
  }

  private getAgent(id: string): Agent {
    const a = (this.agents as Record<string, Agent>)[id] ?? this.extraAgents.get(id);
    if (!a) throw new Error(`Unknown agent: ${id}`);
    return a;
  }

  async run(job: OrchestratorJob): Promise<Record<string, string>> {
    this.events.emit({ type: 'job_start' });
    const outputs: Record<string, string> = {};
    for (const step of job.flow) {
      this.events.emit({ type: 'step_start', step });
      if (step.type === 'agent') {
        const agent = this.getAgent(step.id);
        outputs[step.id] = await agent.run({
          goal: job.goal,
          prior: outputs,
          skills: job.skills,
          mcpServers: job.mcpServers,
          context: job.context,
        });
      } else {
        // reflexion: coder writes, reviewer audits, coder rewrites until approve
        const out = await this.reflexion(step, job, outputs);
        outputs[step.coder] = out.coder;
        outputs[step.reviewer] = out.reviewer;
      }
      this.events.emit({ type: 'step_end', step });
    }
    this.events.emit({ type: 'job_end' });
    return outputs;
  }

  private async reflexion(
    step: Extract<OrchestratorStep, { type: 'reflexion' }>,
    job: OrchestratorJob,
    outputs: Record<string, string>,
  ): Promise<{ coder: string; reviewer: string }> {
    const coder = this.getAgent(step.coder);
    const reviewer = this.getAgent(step.reviewer);
    const maxRounds = step.maxRounds ?? 3;

    let coderOut = '';
    let reviewerOut = '';

    for (let round = 1; round <= maxRounds; round++) {
      this.events.emit({ type: 'reflexion_round', round });

      // Coder run — feed prior reviewer output if any.
      const prior = { ...outputs };
      if (reviewerOut) prior[step.reviewer] = reviewerOut + '\n\n(rewrite addressing the above)';
      coderOut = await coder.run({
        goal: job.goal,
        prior,
        skills: job.skills,
        mcpServers: job.mcpServers,
        context: job.context,
      });

      // Reviewer run — see latest coder output.
      const prior2 = { ...outputs, [step.coder]: coderOut };
      reviewerOut = await reviewer.run({
        goal: job.goal,
        prior: prior2,
        skills: job.skills,
        mcpServers: job.mcpServers,
        context: job.context,
      });

      if (/VERDICT:\s*APPROVE\b/i.test(reviewerOut) || !/REQUEST\s+CHANGES/i.test(reviewerOut)) {
        break;
      }
    }

    return { coder: coderOut, reviewer: reviewerOut };
  }
}

/** A standard 0→1 chain. Use this when building a feature from a prompt. */
export const STANDARD_GREENFIELD_FLOW: OrchestratorStep[] = [
  { type: 'agent', id: 'ba' },
  { type: 'agent', id: 'architect' },
  { type: 'reflexion', coder: 'coder', reviewer: 'reviewer', maxRounds: 2 },
  { type: 'agent', id: 'doc' },
];

/** A 1→N chain. Use this when modifying existing code across multiple repos. */
export const STANDARD_BROWNFIELD_FLOW: OrchestratorStep[] = [
  { type: 'agent', id: 'architect' },        // plan the change
  { type: 'reflexion', coder: 'coder', reviewer: 'reviewer', maxRounds: 3 },
  { type: 'agent', id: 'doc' },              // changelog + migration notes
];
