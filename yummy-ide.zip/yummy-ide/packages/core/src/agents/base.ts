import { Claude, MCPServerSpec } from '../llm/claude.js';
import { Skill } from '../skills/types.js';
import { Emitter } from '../utils/events.js';

export type AgentId = 'ba' | 'architect' | 'coder' | 'reviewer' | 'doc' | string;

export interface AgentEvent {
  type: 'start' | 'token' | 'tool_use' | 'finish' | 'error';
  agent: AgentId;
  /** For 'token' events: the streamed text chunk. */
  text?: string;
  /** For 'tool_use' events. */
  tool?: { name: string; input: unknown };
  /** For 'finish' events: the full output text. */
  output?: string;
  /** For 'error' events. */
  error?: string;
  /** Token usage if available. */
  usage?: { input: number; output: number };
}

export interface AgentInput {
  /** The user's original prompt for this whole job. */
  goal: string;
  /** Outputs of previous agents in the chain. Keyed by agent id. */
  prior: Record<string, string>;
  /** Skills selected by the router. Their bodies become part of the system prompt. */
  skills: Skill[];
  /** MCP servers to attach to this agent's call. */
  mcpServers?: MCPServerSpec[];
  /** Optional codebase / multi-repo context to inject. */
  context?: string;
}

export abstract class Agent {
  public readonly events = new Emitter<AgentEvent>();
  public abstract readonly id: AgentId;
  public abstract readonly name: string;
  public abstract readonly role: string;

  constructor(protected llm: Claude) {}

  /** The role-specific system prompt. Skills are appended automatically. */
  protected abstract systemPrompt(): string;

  /** What tools (besides MCP) does this agent know about?  Override in subclass. */
  protected nativeTools(): never[] { return []; }

  /** Compose the final user message from the input bundle. */
  protected userMessage(input: AgentInput): string {
    const priorBlock = Object.entries(input.prior)
      .map(([k, v]) => `### Output from @${k}\n${v}`)
      .join('\n\n');
    const ctxBlock = input.context ? `### Code context\n${input.context}\n\n` : '';
    return `## Goal
${input.goal}

${ctxBlock}${priorBlock ? `## Prior agent outputs\n${priorBlock}\n\n` : ''}## Your task
Produce your part of the deliverable, in your role as ${this.name}.`;
  }

  async run(input: AgentInput): Promise<string> {
    this.events.emit({ type: 'start', agent: this.id });

    const skillBodies = input.skills
      .map(s => `## Skill: ${s.frontmatter.name}\n${s.body}`)
      .join('\n\n---\n\n');

    const system = `${this.systemPrompt()}

${skillBodies ? `\n\n# Loaded skills\n\n${skillBodies}` : ''}`;

    try {
      const result = await this.llm.complete({
        system,
        messages: [{ role: 'user', content: this.userMessage(input) }],
        mcpServers: input.mcpServers,
        onText: (chunk) => this.events.emit({ type: 'token', agent: this.id, text: chunk }),
        onToolUse: (block) =>
          this.events.emit({
            type: 'tool_use',
            agent: this.id,
            tool: { name: block.name, input: block.input },
          }),
      });
      this.events.emit({
        type: 'finish',
        agent: this.id,
        output: result.text,
        usage: result.usage,
      });
      return result.text;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      this.events.emit({ type: 'error', agent: this.id, error: message });
      throw err;
    }
  }
}
