/**
 * Pluggable embedding store. Default impl is a stub — wire in your provider
 * of choice (Voyage, OpenAI, Cohere, or local BGE/INSTRUCTOR via
 * @xenova/transformers) by implementing the {@link Embedder} interface.
 *
 * For 20 codebases, you typically don't need embeddings — symbol map + FTS5
 * gets you 80% of the way. Embeddings shine for natural-language docs.
 */
import Database from 'better-sqlite3';

export interface Embedder {
  embed(texts: string[]): Promise<number[][]>;
  /** Dimensionality of the produced vectors. */
  dim(): number;
}

/** Stub embedder — returns deterministic dummy vectors. Replace in production. */
export class HashEmbedder implements Embedder {
  constructor(private dimension: number = 256) {}
  dim(): number { return this.dimension; }
  async embed(texts: string[]): Promise<number[][]> {
    return texts.map(t => hashVector(t, this.dimension));
  }
}

function hashVector(text: string, dim: number): number[] {
  const v = new Array(dim).fill(0);
  for (let i = 0; i < text.length; i++) {
    v[(text.charCodeAt(i) * 7) % dim] += 1;
  }
  // L2 normalize
  const n = Math.sqrt(v.reduce((s, x) => s + x * x, 0)) || 1;
  return v.map(x => x / n);
}

export interface DocChunk {
  id: string;
  repo: string;
  file: string;
  line: number;
  text: string;
}

export class EmbeddingStore {
  private db: Database.Database;
  constructor(dbPath: string, private embedder: Embedder) {
    this.db = new Database(dbPath);
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS chunks (
        id    TEXT PRIMARY KEY,
        repo  TEXT, file TEXT, line INTEGER, text TEXT, vec BLOB
      );
    `);
  }

  async upsert(chunks: DocChunk[]): Promise<void> {
    const vecs = await this.embedder.embed(chunks.map(c => c.text));
    const stmt = this.db.prepare(
      `INSERT OR REPLACE INTO chunks (id, repo, file, line, text, vec) VALUES (?,?,?,?,?,?)`,
    );
    const tx = this.db.transaction(() => {
      for (let i = 0; i < chunks.length; i++) {
        const c = chunks[i]!;
        stmt.run(c.id, c.repo, c.file, c.line, c.text, Buffer.from(Float32Array.from(vecs[i]!).buffer));
      }
    });
    tx();
  }

  async search(query: string, k = 8): Promise<DocChunk[]> {
    const [qv] = await this.embedder.embed([query]);
    const all = this.db.prepare(`SELECT id, repo, file, line, text, vec FROM chunks`).all() as Array<DocChunk & { vec: Buffer }>;
    return all
      .map(c => {
        const v = new Float32Array(c.vec.buffer, c.vec.byteOffset, c.vec.byteLength / 4);
        return { c, score: dot(qv!, Array.from(v)) };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, k)
      .map(r => ({ id: r.c.id, repo: r.c.repo, file: r.c.file, line: r.c.line, text: r.c.text }));
  }
}

function dot(a: number[], b: number[]): number {
  let s = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) s += a[i]! * b[i]!;
  return s;
}
