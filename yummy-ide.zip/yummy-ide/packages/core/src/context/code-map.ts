/**
 * Cross-repo code map.
 *
 * For each repo we extract:
 *   - file paths
 *   - top-level symbol declarations (functions, classes, types, exports)
 *   - import statements (so we can build cross-file edges)
 *
 * This is stored in a single SQLite DB with two virtual tables:
 *   - symbols (name, kind, file, line, repo)         — exact + prefix lookup
 *   - symbols_fts (FTS5 over name + signature)        — fuzzy lookup
 *
 * Why SQLite: zero-config, persistent, fast for ≤100k symbols, works offline.
 * Why not LSP: LSP is great for one repo but expensive to keep 20 LSPs alive.
 *
 * The extractor is a pragmatic regex-based scan. For higher fidelity, swap in
 * tree-sitter (web-tree-sitter compiled to wasm). The interface stays the same.
 */
import Database from 'better-sqlite3';
import { resolve, relative, extname } from 'node:path';
import { readFile } from 'node:fs/promises';
import { globby } from 'globby';
import pLimit from 'p-limit';
import { Repo, Workspace } from './workspace.js';

export interface Symbol {
  name: string;
  kind: 'function' | 'class' | 'interface' | 'type' | 'const' | 'enum' | 'export';
  file: string;     // path relative to repo root
  line: number;
  signature: string;
  repo: string;
}

export class CodeMap {
  private db: Database.Database;

  constructor(dbPath: string = ':memory:') {
    this.db = new Database(dbPath);
    this.db.pragma('journal_mode = WAL');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS symbols (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        name      TEXT NOT NULL,
        kind      TEXT NOT NULL,
        file      TEXT NOT NULL,
        line      INTEGER NOT NULL,
        signature TEXT NOT NULL,
        repo      TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols(name);
      CREATE INDEX IF NOT EXISTS idx_symbols_repo ON symbols(repo);

      CREATE VIRTUAL TABLE IF NOT EXISTS symbols_fts USING fts5(
        name, signature, file, repo,
        content='symbols', content_rowid='id'
      );

      CREATE TABLE IF NOT EXISTS imports (
        repo       TEXT NOT NULL,
        from_file  TEXT NOT NULL,
        spec       TEXT NOT NULL    -- the imported module string
      );
      CREATE INDEX IF NOT EXISTS idx_imports_spec ON imports(spec);
    `);
  }

  async indexWorkspace(ws: Workspace): Promise<{ files: number; symbols: number }> {
    const limit = pLimit(8);
    let totalFiles = 0;
    let totalSyms = 0;
    const tasks = ws.repos.map(repo =>
      limit(async () => {
        const r = await this.indexRepo(repo);
        totalFiles += r.files;
        totalSyms += r.symbols;
      }),
    );
    await Promise.all(tasks);
    this.db.exec(`INSERT INTO symbols_fts(symbols_fts) VALUES('rebuild');`);
    return { files: totalFiles, symbols: totalSyms };
  }

  async indexRepo(repo: Repo): Promise<{ files: number; symbols: number }> {
    if (repo.path.startsWith('http')) return { files: 0, symbols: 0 };
    const files = await globby(['**/*.{ts,tsx,js,jsx,py,go,rs,java,kt}'], {
      cwd: repo.path,
      absolute: true,
      gitignore: true,
      ignore: ['**/node_modules/**', '**/dist/**', '**/build/**', '**/.git/**', '**/__pycache__/**'],
    });

    const insertSym = this.db.prepare(
      `INSERT INTO symbols (name, kind, file, line, signature, repo) VALUES (?,?,?,?,?,?)`,
    );
    const insertImp = this.db.prepare(
      `INSERT INTO imports (repo, from_file, spec) VALUES (?,?,?)`,
    );

    // Wipe existing entries for this repo first (idempotent re-index).
    this.db.prepare(`DELETE FROM symbols WHERE repo = ?`).run(repo.name);
    this.db.prepare(`DELETE FROM imports WHERE repo = ?`).run(repo.name);

    let symCount = 0;
    const tx = this.db.transaction((rows: { syms: Symbol[]; imps: { file: string; spec: string }[] }) => {
      for (const s of rows.syms) {
        insertSym.run(s.name, s.kind, s.file, s.line, s.signature, s.repo);
        symCount++;
      }
      for (const i of rows.imps) {
        insertImp.run(repo.name, i.file, i.spec);
      }
    });

    for (const file of files) {
      try {
        const src = await readFile(file, 'utf8');
        const rel = relative(repo.path, file);
        const ext = extname(file);
        const { syms, imps } = extract(src, rel, repo.name, ext);
        tx({ syms, imps });
      } catch {
        // ignore unreadable files
      }
    }
    return { files: files.length, symbols: symCount };
  }

  // ───────────────────────── lookup ────────────────────────────

  findExact(name: string, repo?: string): Symbol[] {
    const sql = repo
      ? `SELECT * FROM symbols WHERE name = ? AND repo = ?`
      : `SELECT * FROM symbols WHERE name = ?`;
    const stmt = this.db.prepare(sql);
    const rows = repo ? stmt.all(name, repo) : stmt.all(name);
    return rows as Symbol[];
  }

  search(query: string, limit = 20): Symbol[] {
    // FTS5 query — escape quotes.
    const q = query.replace(/"/g, '""');
    const stmt = this.db.prepare(
      `SELECT s.* FROM symbols_fts f JOIN symbols s ON s.id = f.rowid
       WHERE symbols_fts MATCH ? LIMIT ?`,
    );
    return stmt.all(`"${q}"*`, limit) as Symbol[];
  }

  /** Files in any repo that import a module matching the given spec. */
  consumersOf(spec: string): { repo: string; file: string }[] {
    const stmt = this.db.prepare(
      `SELECT repo, from_file as file FROM imports WHERE spec LIKE ?`,
    );
    return stmt.all(`%${spec}%`) as { repo: string; file: string }[];
  }

  close(): void {
    this.db.close();
  }
}

// ─────────────────────────── extractors ────────────────────────────────

interface ExtractResult {
  syms: Symbol[];
  imps: { file: string; spec: string }[];
}

function extract(src: string, file: string, repo: string, ext: string): ExtractResult {
  const lines = src.split('\n');
  const syms: Symbol[] = [];
  const imps: { file: string; spec: string }[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i] ?? '';
    if (ext === '.ts' || ext === '.tsx' || ext === '.js' || ext === '.jsx') {
      // imports
      const im = line.match(/^\s*import\s+[^'"]*['"]([^'"]+)['"]/) ||
                 line.match(/^\s*import\s*\(\s*['"]([^'"]+)['"]/);
      if (im) imps.push({ file, spec: im[1]! });

      // export function / class / interface / type / const
      const m = line.match(
        /^\s*export\s+(async\s+)?(function|class|interface|type|const|enum)\s+([A-Za-z_][A-Za-z0-9_]*)/,
      );
      if (m) {
        syms.push({
          name: m[3]!,
          kind: m[2] as Symbol['kind'],
          file,
          line: i + 1,
          signature: line.trim().slice(0, 200),
          repo,
        });
      }
    } else if (ext === '.py') {
      const im = line.match(/^\s*from\s+(\S+)\s+import\b/) || line.match(/^\s*import\s+(\S+)/);
      if (im) imps.push({ file, spec: im[1]! });
      const m = line.match(/^\s*(def|class)\s+([A-Za-z_][A-Za-z0-9_]*)/);
      if (m) {
        syms.push({
          name: m[2]!,
          kind: m[1] === 'def' ? 'function' : 'class',
          file,
          line: i + 1,
          signature: line.trim().slice(0, 200),
          repo,
        });
      }
    } else if (ext === '.go') {
      const m = line.match(/^\s*func\s+([A-Za-z_][A-Za-z0-9_]*)/) ||
                line.match(/^\s*type\s+([A-Za-z_][A-Za-z0-9_]*)\s+(struct|interface)/);
      if (m) {
        syms.push({
          name: m[1]!,
          kind: line.includes('func') ? 'function' : 'type',
          file,
          line: i + 1,
          signature: line.trim().slice(0, 200),
          repo,
        });
      }
    }
  }
  return { syms, imps };
}
