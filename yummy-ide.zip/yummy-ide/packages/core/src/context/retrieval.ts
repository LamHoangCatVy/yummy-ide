/**
 * Hybrid retriever — turns a query (or a planned change) into a compact
 * context window for the agents.
 *
 * Layers (cheap → expensive, stop early):
 *   1. exact symbol match     — "what is `sendMagicLink`?"
 *   2. FTS5 keyword search    — "rate limiting middleware"
 *   3. relation traversal     — "who consumes the user_id field?"
 *   4. embeddings (optional)  — semantic match across docs
 *
 * The output is bounded by token budget. We never blindly stuff files;
 * we stuff the *neighborhood of the symbol* (±20 lines) plus repo manifests.
 */
import { CodeMap, Symbol } from './code-map.js';
import { Workspace, RelationGraph, impactedBy } from './workspace.js';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

export interface RetrievalQuery {
  /** The natural-language query or planned change. */
  text: string;
  /** Symbol names to anchor on, if known. */
  anchors?: string[];
  /** Restrict to specific repos. */
  repos?: string[];
  /** Hard cap on characters to return (rough proxy for tokens). */
  budget?: number;
}

export interface RetrievalResult {
  context: string;
  /** Files actually read. */
  files: { repo: string; file: string; lines: [number, number] }[];
  /** Repos referenced. */
  repos: string[];
}

export class Retriever {
  constructor(
    private workspace: Workspace,
    private codeMap: CodeMap,
    private graph: RelationGraph,
  ) {}

  async retrieve(q: RetrievalQuery): Promise<RetrievalResult> {
    const budget = q.budget ?? 12_000;
    const out: string[] = [];
    const filesRead: RetrievalResult['files'] = [];
    const reposReferenced = new Set<string>();
    let used = 0;

    const append = (s: string, ref?: { repo: string; file: string; lines: [number, number] }) => {
      if (used + s.length > budget) return false;
      out.push(s);
      used += s.length;
      if (ref) {
        filesRead.push(ref);
        reposReferenced.add(ref.repo);
      }
      return true;
    };

    // ── Layer 1: exact anchor symbols ─────────────────────────────
    const seenSymbols = new Set<string>();
    for (const a of q.anchors ?? []) {
      const hits = this.codeMap.findExact(a);
      for (const sym of hits.slice(0, 4)) {
        const key = `${sym.repo}:${sym.file}:${sym.name}`;
        if (seenSymbols.has(key)) continue;
        seenSymbols.add(key);
        const slice = await this.readNeighborhood(sym);
        if (slice && !append(slice.text, { repo: sym.repo, file: sym.file, lines: slice.range })) break;
      }
    }

    // ── Layer 2: FTS keyword search ───────────────────────────────
    const fts = this.codeMap.search(q.text, 12)
      .filter(s => !q.repos || q.repos.includes(s.repo));
    for (const sym of fts) {
      const key = `${sym.repo}:${sym.file}:${sym.name}`;
      if (seenSymbols.has(key)) continue;
      seenSymbols.add(key);
      const slice = await this.readNeighborhood(sym);
      if (slice && !append(slice.text, { repo: sym.repo, file: sym.file, lines: slice.range })) break;
    }

    // ── Layer 3: relation traversal (only when anchors are repo names) ──
    for (const a of q.anchors ?? []) {
      const repo = this.workspace.repos.find(r => r.name === a);
      if (!repo) continue;
      const consumers = impactedBy(this.graph, repo.name);
      if (consumers.length) {
        append(`\n## Repos that depend on \`${repo.name}\`\n${consumers.map(n => `- ${n}`).join('\n')}\n`);
      }
    }

    // ── Layer 4: workspace overview (always, cheap) ───────────────
    const overview = renderWorkspaceOverview(this.workspace, [...reposReferenced]);
    out.unshift(overview);

    return {
      context: out.join('\n\n'),
      files: filesRead,
      repos: [...reposReferenced],
    };
  }

  private async readNeighborhood(sym: Symbol): Promise<{ text: string; range: [number, number] } | null> {
    const repo = this.workspace.repos.find(r => r.name === sym.repo);
    if (!repo || repo.path.startsWith('http')) return null;
    try {
      const src = await readFile(resolve(repo.path, sym.file), 'utf8');
      const lines = src.split('\n');
      const start = Math.max(0, sym.line - 6);
      const end = Math.min(lines.length, sym.line + 20);
      const slice = lines.slice(start, end).join('\n');
      const text = `\n## ${sym.repo} · ${sym.file}:${sym.line}  (${sym.kind} ${sym.name})\n\`\`\`\n${slice}\n\`\`\`\n`;
      return { text, range: [start + 1, end] };
    } catch {
      return null;
    }
  }
}

function renderWorkspaceOverview(ws: Workspace, focus: string[]): string {
  const lines = [`# Workspace: ${ws.name}`, ws.description ?? '', ''];
  lines.push('## Repos');
  for (const r of ws.repos) {
    const star = focus.includes(r.name) ? '★ ' : '  ';
    lines.push(`${star}${r.name.padEnd(24)} role=${r.role}  publishes=[${r.publishes.join(',')}]  consumes=[${r.consumes.join(',')}]`);
  }
  return lines.join('\n');
}
