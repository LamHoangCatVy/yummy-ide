/**
 * The workspace manifest declares all repos that are part of a
 * "logical product" — and the relationships between them.
 *
 * It's the single source of truth for:
 *   - which repos to index
 *   - which repo "owns" a given API contract
 *   - which repos are consumers of which
 *   - environment-specific overrides (dev, staging, prod)
 *
 * Example: examples/workspace.yummy.yml
 */
import { readFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { existsSync } from 'node:fs';
import YAML from 'yaml';
import { z } from 'zod';

export const RepoSchema = z.object({
  name: z.string(),
  path: z.string(),                          // local path or git url
  role: z.enum(['service', 'api', 'frontend', 'library', 'infra', 'data', 'other']),
  language: z.string().optional(),
  /** OpenAPI / GraphQL / Proto / SQL files this repo PUBLISHES. */
  publishes: z.array(z.string()).default([]),
  /** Contracts this repo CONSUMES, by repo name or url. */
  consumes: z.array(z.string()).default([]),
  /** Tags help cluster repos when scoping context. */
  tags: z.array(z.string()).default([]),
  /** Repo-level skill overrides. */
  skills: z.array(z.string()).default([]),
});

export const WorkspaceSchema = z.object({
  name: z.string(),
  description: z.string().optional(),
  repos: z.array(RepoSchema),
  /** Global allow-list of MCP servers for this workspace. */
  mcp: z.array(z.string()).default([]),
});

export type Repo = z.infer<typeof RepoSchema>;
export type Workspace = z.infer<typeof WorkspaceSchema>;

export async function loadWorkspace(yamlPath: string): Promise<Workspace> {
  if (!existsSync(yamlPath)) throw new Error(`Workspace manifest not found: ${yamlPath}`);
  const raw = await readFile(yamlPath, 'utf8');
  const data = YAML.parse(raw);
  const ws = WorkspaceSchema.parse(data);
  // Resolve relative repo paths to absolute.
  const baseDir = dirname(resolve(yamlPath));
  ws.repos = ws.repos.map(r => ({
    ...r,
    path: r.path.startsWith('http') || r.path.startsWith('/') ? r.path : resolve(baseDir, r.path),
  }));
  return ws;
}

/** Build a directed graph of consume/publish relationships. */
export function buildRelationGraph(ws: Workspace): RelationGraph {
  const nodes = new Map(ws.repos.map(r => [r.name, r]));
  const edges: RelationEdge[] = [];
  for (const repo of ws.repos) {
    for (const c of repo.consumes) {
      const target = ws.repos.find(r => r.name === c || r.publishes.some(p => c.endsWith(p)));
      if (target) edges.push({ from: repo.name, to: target.name, kind: 'consumes' });
    }
  }
  return { nodes, edges };
}

export interface RelationEdge {
  from: string;
  to: string;
  kind: 'consumes' | 'publishes' | 'depends';
}
export interface RelationGraph {
  nodes: Map<string, Repo>;
  edges: RelationEdge[];
}

/** Repos that would be impacted if `repo` changes (transitive consumers). */
export function impactedBy(graph: RelationGraph, repoName: string): string[] {
  const visited = new Set<string>();
  const queue = [repoName];
  while (queue.length) {
    const cur = queue.shift()!;
    if (visited.has(cur)) continue;
    visited.add(cur);
    for (const e of graph.edges) {
      if (e.to === cur) queue.push(e.from);
    }
  }
  visited.delete(repoName);
  return [...visited];
}
