import * as vscode from 'vscode';
import { YummyContext } from '../bridge/context.js';
import {
  STANDARD_GREENFIELD_FLOW,
  STANDARD_BROWNFIELD_FLOW,
  loadWorkspace,
  buildRelationGraph,
  CodeMap,
  Retriever,
} from '@yummy/core';
import { resolve } from 'node:path';

export function registerCommands(ctx: vscode.ExtensionContext, y: YummyContext): void {
  // ── open chat ────────────────────────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.openChat', async () => {
    await vscode.commands.executeCommand('yummy.chat.focus');
  }));

  // ── run flow on prompt (greenfield) ──────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.runFlowOnPrompt', async () => {
    const prompt = await vscode.window.showInputBox({
      prompt: 'What do you want to build?',
      placeHolder: 'e.g. magic-link login with 15-min TTL and rate limiting',
    });
    if (!prompt) return;
    await runJob(y, prompt, 'greenfield');
  }));

  // ── run flow on selection ────────────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.runFlow', async () => {
    const editor = vscode.window.activeTextEditor;
    const selection = editor?.document.getText(editor.selection);
    const prompt = await vscode.window.showInputBox({
      prompt: 'What should the agents do with the selection?',
      value: selection ? `Refactor:\n\n${selection.slice(0, 200)}` : '',
    });
    if (!prompt) return;
    await runJob(y, prompt, 'greenfield');
  }));

  // ── invoke a specific skill ──────────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.invokeSkill', async (idArg?: string) => {
    let id = idArg;
    if (!id) {
      const picks = y.skills.list().map(s => ({ label: s.frontmatter.name, description: s.frontmatter.description, id: s.id }));
      const chosen = await vscode.window.showQuickPick(picks, { placeHolder: 'pick a skill to invoke' });
      if (!chosen) return;
      id = chosen.id;
    }
    const skill = y.skills.get(id);
    if (!skill) { vscode.window.showErrorMessage(`unknown skill: ${id}`); return; }
    const prompt = await vscode.window.showInputBox({
      prompt: `Invoke skill "${skill.frontmatter.name}". What do you want?`,
    });
    if (!prompt) return;

    await vscode.commands.executeCommand('yummy.openChat');
    // Just kick off the orchestrator — the chat view streams the events.
    y.orchestrator.run({
      goal: prompt,
      skills: [skill],
      flow: STANDARD_GREENFIELD_FLOW,
      mcpServers: y.mcp.serversFor([skill.id]),
    }).catch(err => vscode.window.showErrorMessage(`flow failed: ${err.message}`));
  }));

  // ── reload skills ────────────────────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.reloadSkills', async () => {
    await y.reloadSkills();
    await vscode.commands.executeCommand('yummy._refreshSkillsView');
    vscode.window.setStatusBarMessage(`$(refresh) Yummy: ${y.skills.list().length} skills loaded`, 3000);
  }));

  // ── connect MCP ──────────────────────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.connectMcp', async () => {
    const name = await vscode.window.showInputBox({ prompt: 'MCP server name', placeHolder: 'e.g. github' });
    if (!name) return;
    const url = await vscode.window.showInputBox({ prompt: 'MCP server URL (https://…)', placeHolder: 'https://mcp.example.com/sse' });
    if (!url) return;
    y.mcp.add({ name, type: 'url', url, enabled: true });
    vscode.window.showInformationMessage(`Yummy: added MCP server "${name}"`);
  }));

  // ── index multi-repo workspace ───────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.indexWorkspace', async () => {
    const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    if (!wsRoot) { vscode.window.showErrorMessage('No workspace folder open'); return; }
    const cfg = vscode.workspace.getConfiguration('yummy');
    const manifestPath = resolve(wsRoot, cfg.get<string>('workspaceManifest') ?? 'workspace.yummy.yml');
    try {
      const ws = await loadWorkspace(manifestPath);
      const graph = buildRelationGraph(ws);
      const codeMap = new CodeMap(resolve(wsRoot, '.yummy.db'));
      const stats = await codeMap.indexWorkspace(ws);
      codeMap.close();
      vscode.window.showInformationMessage(
        `Yummy: indexed ${ws.repos.length} repos · ${stats.files} files · ${stats.symbols} symbols`,
      );
      void graph; // graph is held by the orchestrator at runtime
    } catch (err) {
      vscode.window.showErrorMessage(`Index failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }));

  // ── inline edit (cursor-style ⌘I) ────────────────────────────────────
  ctx.subscriptions.push(vscode.commands.registerCommand('yummy.inlineEdit', async () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor) return;
    const sel = editor.selection;
    const text = editor.document.getText(sel);
    if (!text.trim()) { vscode.window.showWarningMessage('Yummy: select some code first'); return; }

    const instruction = await vscode.window.showInputBox({
      prompt: 'How should I rewrite this?',
      placeHolder: 'e.g. add a try/catch and log errors',
    });
    if (!instruction) return;

    const result = await y.llm.complete({
      system: `You are a code refactoring assistant. Reply with ONLY the rewritten code, no prose, no fences.`,
      messages: [{
        role: 'user',
        content: `Instruction:\n${instruction}\n\nCode:\n\`\`\`\n${text}\n\`\`\``,
      }],
      maxTokens: 1024,
    });
    const newText = stripFences(result.text).trimEnd();
    await editor.edit(b => b.replace(sel, newText));
  }));
}

async function runJob(y: YummyContext, prompt: string, kind: 'greenfield' | 'brownfield'): Promise<void> {
  await vscode.commands.executeCommand('yummy.openChat');
  const skills = await y.router.route(prompt, 3);

  // For brownfield, pull workspace context if available.
  let context: string | undefined;
  const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  const manifestName = vscode.workspace.getConfiguration('yummy').get<string>('workspaceManifest') ?? 'workspace.yummy.yml';
  if (kind === 'brownfield' && wsRoot) {
    try {
      const ws = await loadWorkspace(resolve(wsRoot, manifestName));
      const graph = buildRelationGraph(ws);
      const codeMap = new CodeMap(resolve(wsRoot, '.yummy.db'));
      await codeMap.indexWorkspace(ws);
      const ret = await new Retriever(ws, codeMap, graph).retrieve({ text: prompt });
      codeMap.close();
      context = ret.context;
    } catch { /* manifest absent → fall back to plain greenfield */ }
  }

  y.orchestrator.run({
    goal: prompt,
    skills,
    flow: kind === 'greenfield' ? STANDARD_GREENFIELD_FLOW : STANDARD_BROWNFIELD_FLOW,
    mcpServers: y.mcp.serversFor(skills.map(s => s.id)),
    context,
  }).catch(err => vscode.window.showErrorMessage(`Flow failed: ${err instanceof Error ? err.message : String(err)}`));
}

function stripFences(s: string): string {
  return s.replace(/^```[a-zA-Z0-9_-]*\n?/, '').replace(/```\s*$/, '');
}
