/**
 * Per-VS-Code-window singleton holding all stateful core bits.
 * Lives for the lifetime of the extension activation.
 */
import * as vscode from 'vscode';
import {
  Claude,
  loadSkills,
  Orchestrator,
  SkillRegistry,
  SkillRouter,
  MCPManager,
} from '@yummy/core';

export class YummyContext {
  llm!: Claude;
  skills!: SkillRegistry;
  router!: SkillRouter;
  mcp = new MCPManager();
  orchestrator!: Orchestrator;

  private disposables: vscode.Disposable[] = [];

  constructor(public readonly extCtx: vscode.ExtensionContext, public readonly log: vscode.LogOutputChannel) {}

  async init(): Promise<void> {
    const cfg = vscode.workspace.getConfiguration('yummy');
    const apiKey = cfg.get<string>('apiKey') || process.env.ANTHROPIC_API_KEY || '';
    const dryRun = cfg.get<boolean>('dryRun') ?? !apiKey;

    this.llm = new Claude({
      apiKey: apiKey || undefined,
      defaultModel: cfg.get<string>('model') ?? 'claude-opus-4-7',
      dryRun,
    });
    if (dryRun) this.log.warn('Yummy: running in DRY-RUN mode (no API key configured)');

    await this.reloadSkills();

    // Load MCP config from the workspace root if present.
    const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    if (wsRoot) {
      try {
        await this.mcp.loadConfig(wsRoot);
      } catch (err) {
        this.log.warn(`Yummy: failed to load MCP config: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    this.orchestrator = new Orchestrator(this.llm);
    this.router = new SkillRouter(this.skills, this.llm);

    // React to config changes — no need to ask the user to reload.
    this.disposables.push(
      vscode.workspace.onDidChangeConfiguration(e => {
        if (e.affectsConfiguration('yummy.apiKey') ||
            e.affectsConfiguration('yummy.model') ||
            e.affectsConfiguration('yummy.dryRun')) {
          this.init().catch(err => this.log.error(`re-init failed: ${err}`));
        }
        if (e.affectsConfiguration('yummy.skillsPath')) {
          this.reloadSkills().catch(err => this.log.error(`reload failed: ${err}`));
        }
      }),
    );
  }

  async reloadSkills(): Promise<void> {
    const cfg = vscode.workspace.getConfiguration('yummy');
    const wsRoot = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
    const extra = cfg.get<string>('skillsPath') || undefined;
    const builtinPath = vscode.Uri.joinPath(this.extCtx.extensionUri, 'skills').fsPath;

    const list = await loadSkills({
      workspaceRoot: wsRoot,
      extraPaths: extra ? [extra] : [],
      builtinPath,
    });
    this.skills = new SkillRegistry(list);
    this.log.info(`Yummy: loaded ${list.length} skills`);
  }

  dispose(): void {
    for (const d of this.disposables) {
      try { d.dispose(); } catch { /* ignore */ }
    }
    this.disposables = [];
  }
}
