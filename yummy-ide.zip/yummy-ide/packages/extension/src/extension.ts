/**
 * Yummy/IDE — VS Code extension entry point.
 *
 * On activation we:
 *   1. Build a {@link YummyContext} that holds the LLM client, skill registry,
 *      MCP manager, and orchestrator. This is the per-window singleton.
 *   2. Register all views (chat, skills, agents, tasks).
 *   3. Register commands (run flow, invoke skill, inline edit, etc.).
 *
 * Everything heavyweight lives in @yummy/core; this file is just the host.
 */
import * as vscode from 'vscode';
import { YummyContext } from './bridge/context.js';
import { registerChatView } from './views/chatView.js';
import { registerSkillsView } from './views/skillsView.js';
import { registerAgentsView } from './views/agentsView.js';
import { registerTasksView } from './views/tasksView.js';
import { registerCommands } from './commands/index.js';

let yummy: YummyContext | undefined;

export async function activate(extCtx: vscode.ExtensionContext): Promise<void> {
  const log = vscode.window.createOutputChannel('Yummy', { log: true });
  log.info('Yummy/IDE activating…');

  yummy = new YummyContext(extCtx, log);
  await yummy.init();

  registerChatView(extCtx, yummy);
  registerSkillsView(extCtx, yummy);
  registerAgentsView(extCtx, yummy);
  registerTasksView(extCtx, yummy);
  registerCommands(extCtx, yummy);

  log.info(`Yummy/IDE ready  ·  ${yummy.skills.list().length} skill(s) loaded  ·  ${yummy.mcp.list().length} MCP server(s)`);
  vscode.window.setStatusBarMessage('$(sparkle) Yummy ready', 4000);
}

export function deactivate(): void {
  yummy?.dispose();
  yummy = undefined;
}
