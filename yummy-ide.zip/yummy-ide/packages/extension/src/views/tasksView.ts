import * as vscode from 'vscode';
import { YummyContext } from '../bridge/context.js';

interface Task { id: string; title: string; status: 'todo' | 'doing' | 'done'; tags: string[] }

class TaskItem extends vscode.TreeItem {
  constructor(public readonly task: Task) {
    super(task.title);
    this.description = task.tags.join(', ');
    this.iconPath = new vscode.ThemeIcon(
      task.status === 'done' ? 'check' :
      task.status === 'doing' ? 'sync~spin' : 'circle-large-outline',
    );
    this.contextValue = 'yummy.task';
  }
}

class TaskProvider implements vscode.TreeDataProvider<TaskItem> {
  private _emit = new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData = this._emit.event;

  constructor(private state: { tasks: Task[] }) {}

  getTreeItem(el: TaskItem) { return el; }
  getChildren() { return this.state.tasks.map(t => new TaskItem(t)); }
  refresh() { this._emit.fire(); }
}

export function registerTasksView(ctx: vscode.ExtensionContext, _y: YummyContext): void {
  const state = { tasks: [
    { id: '1', title: 'Wire MCP filesystem server', status: 'todo' as const, tags: ['mcp', 'setup'] },
    { id: '2', title: 'Index multi-repo workspace', status: 'todo' as const, tags: ['context'] },
    { id: '3', title: 'Run greenfield flow demo',   status: 'todo' as const, tags: ['demo'] },
  ] };
  const provider = new TaskProvider(state);
  ctx.subscriptions.push(vscode.window.registerTreeDataProvider('yummy.tasks', provider));
}
