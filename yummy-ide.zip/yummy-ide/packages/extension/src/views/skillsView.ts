import * as vscode from 'vscode';
import { YummyContext } from '../bridge/context.js';

class SkillItem extends vscode.TreeItem {
  constructor(public readonly skillId: string, label: string, desc: string, origin: string) {
    super(label, vscode.TreeItemCollapsibleState.None);
    this.description = origin;
    this.tooltip = desc;
    this.iconPath = new vscode.ThemeIcon('symbol-misc');
    this.command = {
      command: 'yummy.invokeSkill',
      title: 'Invoke skill',
      arguments: [skillId],
    };
    this.contextValue = 'yummy.skill';
  }
}

class SkillsProvider implements vscode.TreeDataProvider<SkillItem> {
  private _onDidChange = new vscode.EventEmitter<SkillItem | undefined | void>();
  readonly onDidChangeTreeData = this._onDidChange.event;

  constructor(private y: YummyContext) {}

  refresh(): void { this._onDidChange.fire(); }

  getTreeItem(el: SkillItem): vscode.TreeItem { return el; }

  getChildren(): SkillItem[] {
    return this.y.skills.list().map(s => new SkillItem(
      s.id,
      s.frontmatter.name,
      s.frontmatter.description,
      s.origin,
    ));
  }
}

export function registerSkillsView(ctx: vscode.ExtensionContext, y: YummyContext): void {
  const provider = new SkillsProvider(y);
  ctx.subscriptions.push(
    vscode.window.registerTreeDataProvider('yummy.skills', provider),
    vscode.commands.registerCommand('yummy._refreshSkillsView', () => provider.refresh()),
  );
}
