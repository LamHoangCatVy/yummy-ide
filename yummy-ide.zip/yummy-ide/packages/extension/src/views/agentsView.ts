import * as vscode from 'vscode';
import { YummyContext } from '../bridge/context.js';

const AGENT_LIST = [
  { id: 'ba',        name: 'Business Analyst',  role: 'PRD · stories · constraints' },
  { id: 'architect', name: 'Solution Architect',role: 'Components · ports · ADRs' },
  { id: 'coder',     name: 'Implementer',       role: 'Code · tests' },
  { id: 'reviewer',  name: 'Reviewer',          role: 'Bugs · security · style' },
  { id: 'doc',       name: 'Doc Writer',        role: 'README · changelog · API docs' },
];

class AgentItem extends vscode.TreeItem {
  constructor(id: string, label: string, role: string) {
    super(label);
    this.description = role;
    this.iconPath = new vscode.ThemeIcon('person');
    this.tooltip = `${label}\n${role}`;
    this.contextValue = 'yummy.agent';
  }
}

export function registerAgentsView(ctx: vscode.ExtensionContext, _y: YummyContext): void {
  const provider: vscode.TreeDataProvider<AgentItem> = {
    getTreeItem: (el) => el,
    getChildren: () => AGENT_LIST.map(a => new AgentItem(a.id, a.name, a.role)),
  };
  ctx.subscriptions.push(vscode.window.registerTreeDataProvider('yummy.agents', provider));
}
