import * as vscode from 'vscode';
import { YummyContext } from '../bridge/context.js';
import { STANDARD_GREENFIELD_FLOW } from '@yummy/core';

/**
 * The "Agent stream" view. This is a webview that renders:
 *   - the BA → Architect → Coder → Reviewer → Doc flow
 *   - per-agent streaming text
 *   - skill traces
 *   - quick chips ("accept all", "@review next")
 *
 * Communication with the extension host is via postMessage: webview asks
 * "send-prompt", host streams back "agent-event" messages.
 */
export function registerChatView(ctx: vscode.ExtensionContext, y: YummyContext): void {
  const provider: vscode.WebviewViewProvider = {
    resolveWebviewView(view) {
      view.webview.options = { enableScripts: true, localResourceRoots: [ctx.extensionUri] };
      view.webview.html = renderHtml();

      // From webview → host
      view.webview.onDidReceiveMessage(async (msg) => {
        if (msg?.type === 'send-prompt') {
          await runFlow(y, view.webview, String(msg.text ?? ''));
        }
      });
    },
  };
  ctx.subscriptions.push(vscode.window.registerWebviewViewProvider('yummy.chat', provider));
}

async function runFlow(y: YummyContext, webview: vscode.Webview, prompt: string): Promise<void> {
  if (!prompt.trim()) return;
  webview.postMessage({ type: 'user', text: prompt });

  // Skill routing.
  const skills = await y.router.route(prompt, 3);
  webview.postMessage({
    type: 'system',
    text: `routed to skills: ${skills.map(s => s.frontmatter.name).join(', ') || '(none)'}`,
  });

  // Stream every orchestrator event into the webview.
  const off = y.orchestrator.events.on(ev => {
    webview.postMessage({ type: 'event', event: ev });
  });

  try {
    await y.orchestrator.run({
      goal: prompt,
      skills,
      flow: STANDARD_GREENFIELD_FLOW,
      mcpServers: y.mcp.serversFor(skills.map(s => s.id)),
    });
  } catch (err) {
    webview.postMessage({ type: 'system', text: `error: ${err instanceof Error ? err.message : String(err)}` });
  } finally {
    off();
  }
}

function renderHtml(): string {
  // Inline HTML — simple, no bundler needed. CSP is strict.
  const nonce = Math.random().toString(36).slice(2);
  return /* html */ `<!doctype html>
<html><head><meta charset="utf-8"/>
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-${nonce}';">
<style>
  body { font-family: var(--vscode-font-family); font-size: var(--vscode-font-size); color: var(--vscode-foreground); padding: 8px; }
  #stream { display: flex; flex-direction: column; gap: 10px; max-height: calc(100vh - 120px); overflow-y: auto; }
  .msg { border-left: 2px solid var(--vscode-textBlockQuote-border); padding: 6px 10px; }
  .msg.user     { border-left-color: var(--vscode-charts-foreground); }
  .msg.ba       { border-left-color: #7ab6c4; }
  .msg.architect{ border-left-color: #c69ae0; }
  .msg.coder    { border-left-color: #ff6a3d; }
  .msg.reviewer { border-left-color: #f4c478; }
  .msg.doc      { border-left-color: #86c46b; }
  .msg.system   { opacity: 0.7; font-style: italic; }
  .who { font-size: 11px; opacity: 0.7; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.08em; }
  .body { white-space: pre-wrap; word-wrap: break-word; font-family: var(--vscode-editor-font-family); font-size: 12px; }
  .composer { position: sticky; bottom: 0; background: var(--vscode-sideBar-background); padding-top: 8px; border-top: 1px solid var(--vscode-panel-border); margin-top: 12px; }
  textarea {
    width: 100%; box-sizing: border-box; resize: vertical; min-height: 60px;
    background: var(--vscode-input-background); color: var(--vscode-input-foreground);
    border: 1px solid var(--vscode-input-border); border-radius: 2px; padding: 6px 8px;
    font-family: var(--vscode-editor-font-family); font-size: 12px;
  }
  button {
    margin-top: 6px; padding: 4px 12px; cursor: pointer;
    background: var(--vscode-button-background); color: var(--vscode-button-foreground);
    border: 0; border-radius: 2px; font-size: 12px;
  }
  button:hover { background: var(--vscode-button-hoverBackground); }
  .hint { font-size: 10px; opacity: 0.6; margin-top: 4px; }
</style></head>
<body>
  <div id="stream"></div>
  <div class="composer">
    <textarea id="prompt" placeholder="describe a change, attach a skill, or @ an agent…"></textarea>
    <button id="send">▶ Run agent flow</button>
    <div class="hint">⌘⏎ to send · streaming live · skills auto-routed</div>
  </div>
  <script nonce="${nonce}">
    const vscode = acquireVsCodeApi();
    const stream = document.getElementById('stream');
    const promptEl = document.getElementById('prompt');
    const sendBtn = document.getElementById('send');

    const liveByAgent = new Map();

    function append(role, text) {
      const div = document.createElement('div');
      div.className = 'msg ' + role;
      div.innerHTML = '<div class="who">' + role + '</div><div class="body"></div>';
      div.querySelector('.body').textContent = text;
      stream.appendChild(div);
      stream.scrollTop = stream.scrollHeight;
      return div;
    }

    function ensureLive(agent) {
      let div = liveByAgent.get(agent);
      if (div) return div;
      div = append(agent, '');
      liveByAgent.set(agent, div);
      return div;
    }

    window.addEventListener('message', (e) => {
      const m = e.data;
      if (m.type === 'user')   { append('user', m.text); return; }
      if (m.type === 'system') { append('system', m.text); return; }
      if (m.type === 'event' && m.event) {
        const ev = m.event;
        if (ev.type === 'agent_event' && ev.agentEvent) {
          const ae = ev.agentEvent;
          if (ae.type === 'start') { liveByAgent.delete(ae.agent); ensureLive(ae.agent); }
          else if (ae.type === 'token') {
            const div = ensureLive(ae.agent);
            div.querySelector('.body').textContent += (ae.text || '');
            stream.scrollTop = stream.scrollHeight;
          }
          else if (ae.type === 'finish') { liveByAgent.delete(ae.agent); }
          else if (ae.type === 'error')  { append('system', '[' + ae.agent + '] error: ' + ae.error); }
        } else if (ev.type === 'reflexion_round') {
          append('system', '── reflexion round ' + ev.round + ' ──');
        } else if (ev.type === 'job_end') {
          append('system', '✓ flow complete');
        }
      }
    });

    function send() {
      const text = promptEl.value.trim();
      if (!text) return;
      vscode.postMessage({ type: 'send-prompt', text });
      promptEl.value = '';
    }
    sendBtn.addEventListener('click', send);
    promptEl.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); send(); }
    });
  </script>
</body></html>`;
}
