#!/usr/bin/env node
/**
 * yummy — terminal-first companion. Inspired by OpenCode's REPL flow.
 *
 * Subcommands (non-interactive):
 *   yummy run "<prompt>"             greenfield flow, code → ./out
 *   yummy refactor "<task>"          brownfield flow against workspace.yummy.yml
 *   yummy skills [list|search <q>]   skill marketplace
 *   yummy index                      build the multi-repo code map
 *
 * No subcommand → interactive REPL:
 *   vy> skill list
 *   vy> agent run yummy-flow
 *   vy> ask why does sendMagicLink not have rate limiting?
 *   vy> exit
 */
import { argv, env, stdin, stdout, exit } from 'node:process';
import { createInterface } from 'node:readline';
import { resolve } from 'node:path';
import {
  Claude,
  loadSkills,
  SkillRegistry,
  SkillRouter,
  Orchestrator,
  STANDARD_GREENFIELD_FLOW,
  loadWorkspace,
  buildRelationGraph,
  CodeMap,
  Retriever,
} from '@yummy/core';

const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m', red: '\x1b[31m',
  green: '\x1b[32m', yellow: '\x1b[33m', blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m',
};

async function main() {
  const args = argv.slice(2);
  const sub = args[0];

  if (sub === 'run') return runOnce(args.slice(1).join(' '));
  if (sub === 'refactor') return refactor(args.slice(1).join(' '));
  if (sub === 'skills') return skillsCmd(args.slice(1));
  if (sub === 'index') return indexCmd();
  if (sub === 'help' || sub === '--help' || sub === '-h') return printHelp();
  if (sub) {
    console.error(`unknown command: ${sub}`);
    printHelp();
    exit(1);
  }

  return repl();
}

async function bootstrapCore() {
  const isDry = !env.ANTHROPIC_API_KEY;
  const llm = new Claude({ dryRun: isDry });
  const wsRoot = process.cwd();
  const skills = await loadSkills({ workspaceRoot: wsRoot });
  const registry = new SkillRegistry(skills);
  const router = new SkillRouter(registry, llm);
  const orchestrator = new Orchestrator(llm);
  return { llm, registry, router, orchestrator, isDry };
}

async function runOnce(prompt: string) {
  if (!prompt) { console.error('usage: yummy run "<prompt>"'); exit(1); }
  const { router, orchestrator } = await bootstrapCore();
  const skills = await router.route(prompt, 3);
  console.log(`${C.dim}routed: ${skills.map(s => s.frontmatter.name).join(', ') || '(none)'}${C.reset}`);
  orchestrator.events.on(ev => {
    if (ev.type === 'agent_event' && ev.agentEvent?.type === 'token') {
      stdout.write(ev.agentEvent.text ?? '');
    } else if (ev.type === 'agent_event' && ev.agentEvent?.type === 'start') {
      stdout.write(`\n${C.cyan}${ev.agentEvent.agent}>${C.reset} `);
    }
  });
  await orchestrator.run({ goal: prompt, skills, flow: STANDARD_GREENFIELD_FLOW });
  console.log();
}

async function refactor(task: string) {
  if (!task) { console.error('usage: yummy refactor "<task>"'); exit(1); }
  const wsManifest = resolve(process.cwd(), 'workspace.yummy.yml');
  const ws = await loadWorkspace(wsManifest);
  const graph = buildRelationGraph(ws);
  const codeMap = new CodeMap(resolve(process.cwd(), '.yummy.db'));
  await codeMap.indexWorkspace(ws);
  const ret = await new Retriever(ws, codeMap, graph).retrieve({ text: task });
  codeMap.close();

  const { router, orchestrator } = await bootstrapCore();
  const skills = await router.route(task, 3);
  orchestrator.events.on(ev => {
    if (ev.type === 'agent_event' && ev.agentEvent?.type === 'token') stdout.write(ev.agentEvent.text ?? '');
    else if (ev.type === 'agent_event' && ev.agentEvent?.type === 'start') stdout.write(`\n${C.magenta}${ev.agentEvent.agent}>${C.reset} `);
  });
  await orchestrator.run({ goal: task, skills, flow: STANDARD_GREENFIELD_FLOW, context: ret.context });
  console.log();
}

async function skillsCmd(rest: string[]) {
  const { registry } = await bootstrapCore();
  const op = rest[0] ?? 'list';
  if (op === 'list') {
    for (const s of registry.list()) {
      console.log(`  ${C.bold}${s.frontmatter.name.padEnd(28)}${C.reset} ${C.dim}${s.origin.padEnd(8)}${C.reset} ${s.frontmatter.description}`);
    }
  } else if (op === 'search') {
    const q = rest.slice(1).join(' ');
    for (const s of registry.search(q)) {
      console.log(`  ${C.bold}${s.frontmatter.name}${C.reset}  ${s.frontmatter.description}`);
    }
  }
}

async function indexCmd() {
  const wsManifest = resolve(process.cwd(), 'workspace.yummy.yml');
  const ws = await loadWorkspace(wsManifest);
  const codeMap = new CodeMap(resolve(process.cwd(), '.yummy.db'));
  const stats = await codeMap.indexWorkspace(ws);
  codeMap.close();
  console.log(`indexed ${ws.repos.length} repos · ${stats.files} files · ${stats.symbols} symbols`);
}

async function repl() {
  const core = await bootstrapCore();
  console.log(`${C.bold}yummy${C.reset} ${C.dim}v0.1 · skill-driven REPL${C.reset}`);
  console.log(`${C.dim}commands: skill list · agent run <id> · ask <q> · refactor <task> · clear · exit${C.reset}\n`);

  const rl = createInterface({ input: stdin, output: stdout, prompt: `${C.cyan}vy>${C.reset} ` });
  rl.prompt();
  rl.on('line', async (raw) => {
    const line = raw.trim();
    if (!line) { rl.prompt(); return; }

    if (line === 'exit' || line === 'quit') { rl.close(); return; }
    if (line === 'clear') { console.clear(); rl.prompt(); return; }

    if (line === 'skill list') {
      for (const s of core.registry.list()) {
        console.log(`  ${s.frontmatter.name.padEnd(28)} ${C.dim}${s.origin}${C.reset}  ${s.frontmatter.description}`);
      }
      rl.prompt(); return;
    }

    if (line.startsWith('ask ') || line.startsWith('run ') || line.startsWith('refactor ')) {
      const [verb, ...rest] = line.split(' ');
      const text = rest.join(' ');
      const skills = await core.router.route(text, 3);
      console.log(`${C.dim}routed:${C.reset} ${skills.map(s => s.frontmatter.name).join(', ') || '(none)'}`);
      const off = core.orchestrator.events.on(ev => {
        if (ev.type === 'agent_event' && ev.agentEvent?.type === 'start') stdout.write(`\n${C.cyan}${ev.agentEvent.agent}>${C.reset} `);
        else if (ev.type === 'agent_event' && ev.agentEvent?.type === 'token') stdout.write(ev.agentEvent.text ?? '');
      });
      try {
        await core.orchestrator.run({ goal: text, skills, flow: STANDARD_GREENFIELD_FLOW });
      } finally {
        off();
      }
      console.log();
      rl.prompt(); return;
    }

    console.log(`${C.dim}(unknown — try: skill list · ask <q> · run <prompt> · refactor <task> · exit)${C.reset}`);
    rl.prompt();
  });
  rl.on('close', () => { console.log(); exit(0); });
}

function printHelp() {
  console.log(`
yummy — terminal companion for the skill-driven IDE

usage:
  yummy                            interactive REPL
  yummy run "<prompt>"             greenfield 5-agent flow
  yummy refactor "<task>"          brownfield (needs workspace.yummy.yml)
  yummy skills [list|search <q>]   skill marketplace
  yummy index                      index the multi-repo code map
  yummy help                       this message
`);
}

main().catch(err => {
  console.error('fatal:', err);
  exit(1);
});
