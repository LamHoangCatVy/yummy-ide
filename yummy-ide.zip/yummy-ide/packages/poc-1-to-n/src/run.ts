#!/usr/bin/env node
/**
 * POC 1 → N.  The brownfield trajectory.
 *
 * What it demonstrates:
 *   1. Index multiple repos declared in workspace.yummy.yml into a SQLite code map.
 *   2. Build a relation graph from the manifest (who consumes whom).
 *   3. Given a refactor task, retrieve the *minimum* relevant context across
 *      all impacted repos using the hybrid retriever (anchors → FTS → graph).
 *   4. Run the brownfield agent flow (Architect → Coder ⇄ Reviewer → Doc) so
 *      the change is *planned* before any line of code is touched.
 *   5. Materialize the planned diffs into ./out/ as patch files (no in-place
 *      writes — safer for a demo + shows the auditable artefact you actually
 *      want when refactoring across 20 repos).
 *
 * Usage:
 *   pnpm --filter @yummy/poc-1-to-n run start -- \
 *     --workspace ./workspace.yummy.yml \
 *     --task "rename field user_id → userId across all consumers"
 *
 * Flags:
 *   --workspace <yaml>    workspace manifest (default: ./workspace.yummy.yml)
 *   --task <string>       what you want to do (required)
 *   --anchors a,b,c       symbol/repo names to seed retrieval
 *   --repos a,b           limit retrieval to specific repos
 *   --budget 12000        max context chars
 *   --out ./out           where to write the plan + patches
 *   --dry-run             force offline mode
 *   --no-write            don't materialize anything (just print)
 */
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { argv, env, exit, stdout } from 'node:process';
import {
  Claude,
  CodeMap,
  Orchestrator,
  STANDARD_BROWNFIELD_FLOW,
  Retriever,
  buildRelationGraph,
  impactedBy,
  loadSkills,
  loadWorkspace,
  SkillRegistry,
  SkillRouter,
} from '@yummy/core';

interface Args {
  workspace: string;
  task: string;
  anchors: string[];
  repos: string[];
  budget: number;
  out: string;
  dryRun: boolean;
  write: boolean;
  skillsPath?: string;
}

function parseArgs(raw: string[]): Args {
  const a: Args = {
    workspace: resolve(process.cwd(), 'workspace.yummy.yml'),
    task: '',
    anchors: [],
    repos: [],
    budget: 12_000,
    out: resolve(process.cwd(), 'out'),
    dryRun: false,
    write: true,
  };
  for (let i = 0; i < raw.length; i++) {
    const k = raw[i];
    if (k === '--workspace') a.workspace = resolve(raw[++i] ?? '');
    else if (k === '--task') a.task = raw[++i] ?? '';
    else if (k === '--anchors') a.anchors = (raw[++i] ?? '').split(',').filter(Boolean);
    else if (k === '--repos') a.repos = (raw[++i] ?? '').split(',').filter(Boolean);
    else if (k === '--budget') a.budget = parseInt(raw[++i] ?? '12000', 10);
    else if (k === '--out') a.out = resolve(raw[++i] ?? './out');
    else if (k === '--dry-run') a.dryRun = true;
    else if (k === '--no-write') a.write = false;
    else if (k === '--skills') a.skillsPath = raw[++i];
    else if (k === '--help' || k === '-h') { help(); exit(0); }
  }
  if (!a.task) { help(); exit(1); }
  return a;
}

function help() {
  console.error(`
yummy/poc-1-to-n  —  multi-repo refactor with workspace-aware context

Usage:
  pnpm --filter @yummy/poc-1-to-n run start -- \\
    --workspace ./workspace.yummy.yml \\
    --task "rename field user_id → userId across all consumers" \\
    --anchors user_id,Principal

Flags:
  --workspace <yaml>   workspace manifest (default: ./workspace.yummy.yml)
  --task <string>      what to do (required)
  --anchors a,b,c      symbol/repo names to seed retrieval
  --repos a,b          restrict retrieval to certain repos
  --budget 12000       max context characters
  --out <dir>          output directory for plan + patches
  --dry-run            offline mode (canned responses)
  --no-write           print only, don't materialize files
`);
}

const C = {
  reset: '\x1b[0m', dim: '\x1b[2m', bold: '\x1b[1m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m',
};
const AGENT_COLOR: Record<string, string> = {
  architect: C.magenta, coder: C.cyan, reviewer: C.yellow, doc: C.green,
};

async function main() {
  const args = parseArgs(argv.slice(2));
  const isDry = args.dryRun || !env.ANTHROPIC_API_KEY;

  banner(`POC 1 → N  ·  ${isDry ? 'DRY-RUN' : 'LIVE'}`);
  console.log(`${C.dim}task:      ${C.reset}${args.task}`);
  console.log(`${C.dim}workspace: ${C.reset}${args.workspace}`);
  console.log(`${C.dim}anchors:   ${C.reset}${args.anchors.join(', ') || '(none)'}`);
  console.log(`${C.dim}budget:    ${C.reset}${args.budget} chars\n`);

  // 1. Load workspace + build relation graph.
  const ws = await loadWorkspace(args.workspace);
  const graph = buildRelationGraph(ws);
  console.log(`${C.bold}● workspace${C.reset}  "${ws.name}"  ·  ${ws.repos.length} repo(s)`);
  for (const r of ws.repos) {
    const edges = impactedBy(graph, r.name);
    console.log(`  - ${r.name.padEnd(20)} role=${r.role}  impacted-by-changes-here=[${edges.join(',') || '∅'}]`);
  }

  // 2. Index every repo into a SQLite code map.
  console.log(`\n${C.bold}● indexing${C.reset}`);
  const dbPath = resolve(dirname(args.workspace), '.yummy.db');
  const codeMap = new CodeMap(dbPath);
  const t0 = Date.now();
  const stats = await codeMap.indexWorkspace(ws);
  console.log(`  indexed ${stats.files} file(s), ${stats.symbols} symbol(s) in ${Date.now() - t0}ms → ${dbPath}`);

  // 3. Hybrid retrieval.
  console.log(`\n${C.bold}● retrieving context${C.reset}`);
  const retriever = new Retriever(ws, codeMap, graph);
  const auto = autoAnchorsFromTask(args.task);
  const anchors = [...new Set([...args.anchors, ...auto])];
  console.log(`  anchors (auto + user): ${anchors.join(', ') || '(none)'}`);
  const ret = await retriever.retrieve({
    text: args.task,
    anchors,
    repos: args.repos.length ? args.repos : undefined,
    budget: args.budget,
  });
  console.log(`  pulled ${ret.files.length} file slice(s) from ${ret.repos.length} repo(s)`);
  for (const f of ret.files) console.log(`    ${C.dim}·${C.reset} ${f.repo}/${f.file}:${f.lines[0]}-${f.lines[1]}`);

  // 4. Load skills, route, build agent flow.
  const skills = await loadSkills({ workspaceRoot: args.skillsPath ?? resolve(import.meta.dirname ?? '.', '../../../skills') });
  const registry = new SkillRegistry(skills);
  const llm = new Claude({ dryRun: isDry });
  const router = new SkillRouter(registry, llm);
  const picked = await router.route(args.task, 3);
  console.log(`\n${C.bold}● skills${C.reset}  loaded ${skills.length}, routed to: ${picked.map(s => s.frontmatter.name).join(', ') || '(none)'}\n`);

  // 5. Run the brownfield flow with retrieved context injected.
  const orch = new Orchestrator(llm);
  orch.events.on(ev => {
    if (ev.type === 'step_start' && ev.step?.type === 'agent') {
      console.log(`\n${C.dim}── ${ev.step.id} ──${C.reset}`);
    } else if (ev.type === 'reflexion_round') {
      console.log(`\n${C.dim}── reflexion round ${ev.round} ──${C.reset}`);
    } else if (ev.type === 'agent_event' && ev.agentEvent) {
      const ae = ev.agentEvent;
      if (ae.type === 'start') {
        const c = AGENT_COLOR[ae.agent] ?? C.reset;
        stdout.write(`${c}${ae.agent}>${C.reset} `);
      } else if (ae.type === 'token') {
        stdout.write(ae.text ?? '');
      } else if (ae.type === 'finish') {
        stdout.write('\n');
      }
    }
  });

  const t1 = Date.now();
  const outputs = await orch.run({
    goal: args.task,
    skills: picked,
    flow: STANDARD_BROWNFIELD_FLOW,
    context: ret.context,
  });
  const elapsed = ((Date.now() - t1) / 1000).toFixed(1);

  // 6. Materialize artefacts: plan.md + per-repo patch.diff hints.
  if (args.write) {
    console.log(`\n${C.bold}● writing plan + patches${C.reset}  → ${args.out}`);
    await mkdir(args.out, { recursive: true });

    // The full plan markdown — what an architect approves before any commit.
    const planMd = renderPlan({
      task: args.task,
      workspace: ws.name,
      anchors,
      retrieved: ret,
      architect: outputs.architect ?? '',
      coder: outputs.coder ?? '',
      reviewer: outputs.reviewer ?? '',
      doc: outputs.doc ?? '',
    });
    const planPath = resolve(args.out, 'plan.md');
    await writeFile(planPath, planMd, 'utf8');
    console.log(`  ${C.green}+${C.reset} ${planPath}`);

    // Per-repo patch stub — one file per impacted repo, copy-pasteable into a real PR.
    const repos = inferImpactedRepos(ws, anchors, graph);
    for (const repoName of repos) {
      const patchPath = resolve(args.out, `${repoName}.patch.md`);
      await writeFile(
        patchPath,
        renderRepoPatchStub(repoName, args.task, outputs.coder ?? ''),
        'utf8',
      );
      console.log(`  ${C.green}+${C.reset} ${patchPath}`);
    }

    // Audit trail — verbatim retrieved context.
    const ctxPath = resolve(args.out, 'context.snapshot.md');
    await writeFile(ctxPath, ret.context, 'utf8');
    console.log(`  ${C.green}+${C.reset} ${ctxPath}`);
  }

  codeMap.close();
  banner(`DONE in ${elapsed}s`);
}

// ───────────────────────── helpers ────────────────────────────────────

function banner(s: string) {
  const line = '─'.repeat(s.length + 4);
  console.log(`\n${C.bold}┌${line}┐${C.reset}`);
  console.log(`${C.bold}│  ${s}  │${C.reset}`);
  console.log(`${C.bold}└${line}┘${C.reset}`);
}

/** Heuristic: pull capitalized-or-snake_case identifiers out of the task string. */
function autoAnchorsFromTask(task: string): string[] {
  const tokens = task.match(/\b[A-Z][A-Za-z0-9_]+|\b[a-z]+_[a-z_]+\b/g) ?? [];
  return [...new Set(tokens)];
}

function inferImpactedRepos(
  ws: ReturnType<typeof loadWorkspace> extends Promise<infer T> ? T : never,
  anchors: string[],
  graph: ReturnType<typeof buildRelationGraph>,
): string[] {
  // If an anchor is a repo name, expand to its consumers.
  const result = new Set<string>();
  for (const a of anchors) {
    const repo = ws.repos.find(r => r.name === a);
    if (repo) {
      result.add(repo.name);
      for (const c of impactedBy(graph, repo.name)) result.add(c);
    }
  }
  if (result.size === 0) {
    for (const r of ws.repos) result.add(r.name);
  }
  return [...result];
}

function renderPlan(o: {
  task: string;
  workspace: string;
  anchors: string[];
  retrieved: { files: { repo: string; file: string; lines: [number, number] }[]; repos: string[] };
  architect: string;
  coder: string;
  reviewer: string;
  doc: string;
}): string {
  return `# Cross-repo refactor plan

**Task:** ${o.task}
**Workspace:** ${o.workspace}
**Anchors:** ${o.anchors.join(', ') || '(none)'}
**Generated:** ${new Date().toISOString()}

## Files surfaced by retrieval (${o.retrieved.files.length})

${o.retrieved.files.map(f => `- ${f.repo}/${f.file}:${f.lines[0]}-${f.lines[1]}`).join('\n')}

---

## 1. Architecture plan

${o.architect}

---

## 2. Proposed changes (per file)

${o.coder}

---

## 3. Review verdict

${o.reviewer}

---

## 4. Migration / changelog notes

${o.doc}
`;
}

function renderRepoPatchStub(repo: string, task: string, coderOutput: string): string {
  // Pull only the code blocks whose path hint mentions this repo.
  const re = /```([a-zA-Z0-9_+-]*)\n((?:\/\/|#)\s*([\w./\-]+\.\w+)[\s\S]*?)```/g;
  const blocks: string[] = [];
  let m: RegExpExecArray | null;
  while ((m = re.exec(coderOutput)) !== null) {
    if (m[3] && m[3].includes(repo)) {
      blocks.push('```' + m[1] + '\n' + m[2] + '\n```');
    }
  }
  return `# ${repo} · proposed changes

**Task:** ${task}

${blocks.length ? blocks.join('\n\n') : '_(no blocks attributed to this repo — check plan.md for the full diff and split manually)_'}

---

## How to apply

1. Open this repo locally.
2. Compare each block above against the current file. The first line of each block is the file path.
3. After applying, run \`pnpm test\` and \`pnpm typecheck\`.
4. Open a PR with title "${task}" and link to the plan.md from this run.
`;
}

main().catch(err => {
  console.error('fatal:', err);
  exit(1);
});
