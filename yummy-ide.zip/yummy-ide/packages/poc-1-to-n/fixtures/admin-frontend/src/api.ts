// admin-frontend/src/api.ts
import type { Principal } from '../../auth-service/src/types.js';

export async function fetchUser(user_id: string, me: Principal) {
  const res = await fetch(`/api/users/${user_id}`, {
    headers: { 'x-actor': me.user_id },
  });
  if (!res.ok) throw new Error(`fetchUser ${user_id} failed: ${res.status}`);
  return res.json() as Promise<{ user_id: string; display_name: string }>;
}

export async function listUsers(me: Principal) {
  const res = await fetch('/api/users', { headers: { 'x-actor': me.user_id } });
  return res.json() as Promise<Array<{ user_id: string; display_name: string }>>;
}
