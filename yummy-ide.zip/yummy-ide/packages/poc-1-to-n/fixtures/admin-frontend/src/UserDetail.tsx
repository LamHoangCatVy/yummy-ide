// admin-frontend/src/UserDetail.tsx
// Frontend consumer. Reads user_id off the wire response.
// A coherent refactor must rename this too — or break the contract.

import type { Principal } from '../../auth-service/src/types.js';

interface UserResponse {
  user_id: string;
  display_name: string;
  created_at: number;
}

export interface UserDetailProps {
  me: Principal;
  user: UserResponse;
}

export function UserDetail(props: UserDetailProps) {
  const { me, user } = props;
  const isSelf = me.user_id === user.user_id;
  // Pseudo-JSX (don't need a real React build for the POC)
  return {
    type: 'div',
    children: [
      { type: 'h1', text: user.display_name },
      { type: 'p',  text: `id: ${user.user_id}` },
      { type: 'p',  text: `viewing as: ${me.user_id}${isSelf ? ' (you)' : ''}` },
    ],
  };
}

export function buildEditLink(p: Principal): string {
  return `/admin/users/${p.user_id}/edit`;
}
