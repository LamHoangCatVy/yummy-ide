// user-api/src/routes.ts
import { getMe, updateProfile, audit } from './handlers.js';
import type { Principal } from '../../auth-service/src/types.js';

// Mock router — real impl would be express/fastify/hono.
type Handler = (req: { principal: Principal; body: any }) => Promise<unknown>;

export const routes: Record<string, Handler> = {
  'GET /me': async ({ principal }) => {
    audit(principal, 'me.read');
    return getMe(principal);
  },
  'PATCH /me': async ({ principal, body }) => {
    audit(principal, 'me.update');
    return updateProfile(principal, body.display_name);
  },
  'GET /users/:user_id': async ({ principal }) => {
    audit(principal, 'user.read');
    // Note: param name is also user_id — refactor must touch this too.
    return getMe(principal);
  },
};

// Persistence layer query — yet another place user_id appears.
export const SQL_FIND_USER = `SELECT user_id, display_name, created_at
                              FROM users WHERE user_id = $1`;
