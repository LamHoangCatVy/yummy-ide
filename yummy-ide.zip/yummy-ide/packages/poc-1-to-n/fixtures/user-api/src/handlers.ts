// user-api/src/handlers.ts
// Consumes Principal from auth-service. Notice every reference to user_id —
// these are exactly the call sites the cross-repo refactor must update.

import type { Principal } from '../../auth-service/src/types.js';

interface UserRecord {
  user_id: string;
  display_name: string;
  created_at: number;
}

const db = new Map<string, UserRecord>();

export async function getMe(p: Principal): Promise<UserRecord | null> {
  return db.get(p.user_id) ?? null;
}

export async function updateProfile(p: Principal, display_name: string): Promise<UserRecord> {
  const existing = db.get(p.user_id);
  const next: UserRecord = existing
    ? { ...existing, display_name }
    : { user_id: p.user_id, display_name, created_at: Date.now() };
  db.set(p.user_id, next);
  return next;
}

export function audit(p: Principal, action: string): void {
  console.log(`[audit] user=${p.user_id} action=${action} t=${Date.now()}`);
}
