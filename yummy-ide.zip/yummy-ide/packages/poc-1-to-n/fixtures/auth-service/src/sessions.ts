// auth-service/src/sessions.ts
import { Principal, Session } from './types.js';

export function issueSession(p: Principal): Session {
  return {
    token: crypto.randomUUID(),
    principal: p,
    expires_at: Date.now() + 60 * 60 * 1000,
  };
}

export function principalToClaims(p: Principal) {
  // JWT-style claims. Note: the wire format also uses `user_id`.
  return {
    sub: p.user_id,
    email: p.email,
    roles: p.roles,
    iat: p.issued_at,
  };
}

export function isExpired(s: Session): boolean {
  return s.expires_at < Date.now();
}
