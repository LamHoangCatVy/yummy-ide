// auth-service/src/types.ts
// Authoritative shape of an authenticated principal — published by auth-service.
// Other services must NOT redefine this.

export interface Principal {
  user_id: string;            // ← the field our refactor will rename
  email: string;
  roles: string[];
  issued_at: number;
}

export interface Session {
  token: string;
  principal: Principal;
  expires_at: number;
}
