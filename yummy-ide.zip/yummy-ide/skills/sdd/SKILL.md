---
name: sdd
description: |
  Spec-driven development. Use whenever the user is building a new feature
  from a fuzzy prompt — the kind of request that needs to become a PRD, an
  architecture doc, code, and tests in that order. Triggers on phrases like
  "build", "add", "create a feature", "ship", "implement", or any request
  that has not yet been decomposed into a concrete plan.
tags: [sdlc, planning, greenfield, multi-agent]
agents: [ba, architect, coder, reviewer, doc]
allowed_mcp_tools: [filesystem, github]
invokes: [code-review, adr-writer]
license: MIT
---

# Spec-Driven Development

You are following the *Yummy* SDD playbook. The goal is to turn an underspecified
request into shippable code without skipping any of the four gates: spec → design
→ implementation → review.

## Gate 1 · Spec (BA)

Produce a PRD with these sections in order:
1. **Problem** — one paragraph, evidence-based if numbers are available.
2. **Goals** — measurable success criteria.
3. **User stories** — "As a __, I want __, so that __."
4. **Constraints** — security, performance, compliance. Cite policy IDs.
5. **Open questions** — list assumptions you're making, don't stall.
6. **Out of scope** — explicit non-goals.

Style: terse, bulleted, one sentence per bullet.

## Gate 2 · Design (Architect)

From the PRD produce:
1. **Components** — modules with single responsibilities.
2. **Ports & adapters** — exact interface signatures.
3. **Sequence** — happy path as numbered calls.
4. **Edge cases** — failures, retries, partial results.
5. **ADRs** — Architecture Decision Records, 3-5 lines each.
6. **Test strategy** — what to mock vs. integrate.

Reuse existing ports if they appear in the codebase context. Don't invent
parallel abstractions.

## Gate 3 · Implementation (Coder)

- One file per fenced code block. First line is `// path/to/file.ext`.
- Honor every constraint in the PRD.
- Tests live next to the code (`module.ts` ↔ `module.test.ts`).
- If the design and a constraint conflict, the constraint wins. Add a comment
  explaining the deviation.

## Gate 4 · Review (Reviewer)

Multi-aspect audit: bug-hunter, security-auditor, test-coverage, style.
Output a verdict line: APPROVE | REQUEST CHANGES | NEEDS DESIGN REVIEW.

If REQUEST CHANGES, the orchestrator will route back to the Coder. Up to 3
reflexion rounds before escalating.

## Anti-patterns

- ❌ Writing code before the PRD is signed off
- ❌ Skipping the architecture step "to save time"
- ❌ Reviewer that finds zero issues on first pass — re-read the security policy
- ❌ Coder pasting the entire response as one giant code block

## Calling other skills

When the work touches public API contracts, also load `adr-writer`. When the
review finds 3+ issues, load `code-review` for a deeper second pass.
