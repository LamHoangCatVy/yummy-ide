---
name: multi-repo-refactor
description: |
  Cross-repo coherent change. Use when a change must propagate across multiple
  codebases that share a contract (rename a field, move an endpoint, deprecate
  a method). Triggers on phrases like "rename across", "migrate", "propagate",
  "all consumers", or any task that names more than one repo. Activates the
  multi-repo context engine before planning.
tags: [refactor, brownfield, cross-repo, migration]
agents: [architect, coder, reviewer, doc]
allowed_mcp_tools: [filesystem, github]
invokes: [code-review, migration-orchestrator, adr-writer]
license: MIT
---

# Multi-repo coherent refactor

The risk in cross-repo work is *partial migration*: producer changes, consumers
break in production. This playbook prevents that by planning before writing.

## Phase 1 · Discover (Architect)

Inputs: workspace manifest + relation graph + retrieved code slices.

Produce a **change set table**:

| repo | file | change | reason |
|------|------|--------|--------|
| auth-service | src/types.ts | rename field `user_id` → `userId` | publishes contract |
| user-api | src/handlers.ts | update all call sites | direct consumer |
| user-api | src/routes.ts | update SQL + URL param name | wire format consumer |
| admin-frontend | src/api.ts | update fetch response type | indirect consumer |
| admin-frontend | src/UserDetail.tsx | update prop type | indirect consumer |

Any consumer that does NOT appear in the table is either:
- not actually impacted (justify in 1 line), or
- a gap — go find it before proceeding.

## Phase 2 · Sequence (Architect)

Order matters. The default safe order is:

1. **Add the new** alongside the old (backward-compatible).
2. **Migrate consumers** one at a time, leaf-first (frontend → api → service).
3. **Switch defaults** so the new path is preferred.
4. **Remove the old** in a follow-up PR after a soak period.

If the manifest shows a strict `consumes:` chain, follow it in reverse.

## Phase 3 · Implement (Coder)

For each row in the change set, emit one fenced block:
```ts
// <repo>/<path>/<file>.ts
…full new content of the file…
```

The first line of every block must be the repo-prefixed path. The orchestrator
splits these into per-repo patch files.

## Phase 4 · Review (Reviewer)

In addition to the standard `code-review` lenses, check:
- **Contract test coverage** — at least one test that exercises the new
  contract shape end-to-end.
- **Rollback plan** — can we revert each repo independently?
- **Dual-write window** — if applicable, is there a flag to switch back?

## Phase 5 · Document (Doc)

Produce:
- `CHANGELOG.md` entry per repo
- `docs/migration/<change-name>.md` with the timeline and the rollback plan
- ADR if a contract semantically changed (not just renamed)

## Hard rules

- ❌ Never edit a consumer before the producer's new contract exists.
- ❌ Never delete the old contract in the same PR that adds the new one.
- ❌ Never produce a change set without justifying which consumers were checked.
