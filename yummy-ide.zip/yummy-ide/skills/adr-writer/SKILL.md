---
name: adr-writer
description: |
  Write Architecture Decision Records. Use whenever the conversation produces
  a non-obvious technical choice that future engineers will want to understand
  the *why* of: technology selection, data model decision, API shape decision,
  deprecation plan, security trade-off. Auto-loaded by sdd and multi-repo-refactor.
tags: [docs, architecture, governance]
agents: [architect, doc]
license: MIT
---

# ADR writer

ADRs document the *why*, not the *what*. The code shows the what.

## Format

```
# ADR-NNN: <one-line decision>

* Status: Proposed | Accepted | Deprecated | Superseded by ADR-XXX
* Date: YYYY-MM-DD
* Deciders: <names or roles>

## Context

What problem are we solving? What forces are at play (technical, organizational,
political)? Two paragraphs maximum.

## Decision

The chosen approach in 1–3 sentences. Active voice. "We will…"

## Consequences

### Positive
- …

### Negative
- …

### Neutral
- …

## Alternatives considered

- **Option A** — 1 line summary, 1 line why-not
- **Option B** — same
```

## Rules

- One decision per ADR. If you find yourself listing 3 decisions, you have 3 ADRs.
- ADRs are immutable. To change a decision, write a new ADR that supersedes the old.
- Cite the ADR number in code comments at the deviation site (`// ADR-007`).
- Avoid adjectives. "Better", "cleaner", "more scalable" are not arguments.
