---
name: code-review
description: |
  Multi-aspect PR audit. Use when the user asks to "review", "audit", "check",
  or "find bugs in" code — also auto-loaded by sdd at gate 4. Runs four
  parallel lenses: bug-hunter, security-auditor, test-coverage, style.
tags: [review, audit, security, quality]
agents: [reviewer]
allowed_mcp_tools: [filesystem, github]
license: MIT
---

# Code review playbook

Run all four lenses; merge findings; classify severity; produce a verdict.

## Lens 1 · Bug-hunter

Look specifically for:
- Off-by-one errors and unchecked array access
- Null / undefined paths the type system has been tricked into accepting
- Race conditions: concurrent reads with non-atomic writes, missing locks
- Resource leaks: open handles, timers, connections not closed
- Error swallowing: `catch {}` with no logging or rethrow
- Time bugs: timezone assumptions, DST, monotonic vs wall-clock

## Lens 2 · Security-auditor

Look for:
- Secrets in source, logs, or error messages
- Injection: SQL, command, HTML, log forging
- Auth bypass: missing `requireAuth`, predictable tokens, weak crypto
- Authorization holes: actor not checked against resource owner
- Policy violations — cite the policy ID (e.g. SEC-014)
- Untrusted deserialization, SSRF, open redirect

## Lens 3 · Test-coverage

- What's tested by the diff?
- What's *not* tested but should be?
- Where would a property test catch a class of bugs better than examples?
- Are mocks hiding real integration risk?

## Lens 4 · Style & contracts

- Public API shape — naming, parameter order, return types
- Error types — domain errors vs leaking infra errors
- Observability — structured logs, metrics, trace spans on the hot path
- Comment-as-design vs. comment-as-noise

## Output format

```
## Review

**N blocking, M non-blocking, K nits.**

### Blocking
- [aspect] file:line — finding

### Non-blocking
- [aspect] file:line — finding

### Verdict
APPROVE | REQUEST CHANGES | NEEDS DESIGN REVIEW
```

A finding without `file:line` is not a finding.
If you genuinely find nothing, say so plainly. Do not invent issues to seem rigorous.
