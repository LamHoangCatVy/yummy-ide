---
name: migration-orchestrator
description: |
  Safely sequence a rollout that spans multiple repos and environments
  (dev → staging → prod). Use when the user mentions "rollout", "migration",
  "feature flag", "canary", "deploy in waves", or asks how to ship a change
  that has dual-write or backfill steps.
tags: [migration, rollout, safety, brownfield]
agents: [architect, coder, doc]
license: MIT
---

# Migration orchestrator

## The expand–migrate–contract pattern

For any change that breaks a contract (renaming a field, splitting a service,
moving a table), use the three-phase pattern:

1. **Expand** — add the new shape alongside the old. Both work simultaneously.
2. **Migrate** — switch every consumer to the new shape, one at a time.
3. **Contract** — remove the old shape in a follow-up release.

Each phase is a separate PR. Each is independently revertable.

## Wave order

Default order, leaf → root:
```
frontend → public API → internal API → service layer → data layer
```

Reverse the order for additive changes (a new field flowing outward), keep
this order for breaking changes (consumers must absorb the change first).

## Feature-flag template

For risky changes, gate every code path on a flag:
```
if (flags.enable_user_id_v2) {
  // new path
} else {
  // old path
}
```

Roll the flag from 0 % → 1 % → 10 % → 50 % → 100 % over at least three days,
with monitoring at each step.

## Rollback checklist

Before merging the *expand* PR, verify all of:
- [ ] Old code path still works with no flag set
- [ ] New code path is dark-launchable (0 % traffic)
- [ ] There is a single revert that returns the system to a known-good state
- [ ] Metric / log line that would tell us the new path is failing

## Document deliverables

For each migration produce:
- A timeline doc (`docs/migration/<name>.md`) with phase dates
- A rollback runbook (one page, copy-pasteable commands)
- An ADR if the data model changed semantically (use `adr-writer`)
